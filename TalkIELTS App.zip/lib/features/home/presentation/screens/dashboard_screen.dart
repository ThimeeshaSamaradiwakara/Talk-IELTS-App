import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:iel/shared/providers/user_provider.dart';
import '../../../auth/presentation/providers/auth_provider.dart';

// Create a provider for user analytics to properly handle data fetching and state
final userAnalyticsProvider = FutureProvider.autoDispose<Map<String, dynamic>?>((ref) async {
  final user = ref.read(currentUserProvider);
  if (user == null) return null;

  try {
    final practiceResults = await FirebaseFirestore.instance
        .collection('practice_results')
        .where('userId', isEqualTo: user.uid)
        .get();

    print('Fetched ${practiceResults.docs.length} practice results'); // Debug print

    if (practiceResults.docs.isEmpty) return null;

    return _calculateAnalytics(practiceResults.docs);
  } catch (e) {
    print('Error fetching user analytics: $e');
    throw e;
  }
});

Map<String, dynamic> _calculateAnalytics(List<QueryDocumentSnapshot> docs) {
  double totalScore = 0;
  int totalTests = 0;
  int totalMinutesStudied = 0;
  int totalSessions = docs.length;
  Map<String, double> skillScores = {
    'reading': 0,
    'writing': 0,
    'listening': 0,
    'speaking': 0,
  };
  Map<String, int> skillCounts = {
    'reading': 0,
    'writing': 0,
    'listening': 0,
    'speaking': 0,
  };

  for (var doc in docs) {
    final data = doc.data() as Map<String, dynamic>;
    final score = (data['score'] as num).toDouble();
    totalScore += score;
    totalTests++;
    totalMinutesStudied += (data['timeTaken'] as int);

    final testDetails = data['testDetails'] as Map<String, dynamic>;
    final type = testDetails['type'] as String;
    if (skillScores.containsKey(type)) {
      skillScores[type] = (skillScores[type]! + score);
      skillCounts[type] = (skillCounts[type] ?? 0) + 1;
    }
  }

  final overallScore = totalTests > 0 ? (totalScore / totalTests) : 0;

  // Ensure all skill scores have a minimum value of 1.0 to avoid chart errors
  skillScores.forEach((key, value) {
    final count = skillCounts[key] ?? 1;
    double avgScore = count > 0 ? value / count : 0;
    // Ensure minimum score is 1.0 to prevent chart assertion error
    skillScores[key] = avgScore < 1.0 ? 1.0 : avgScore;
  });

  print('Calculated analytics: $skillScores'); // Debug print

  return {
    'overallScore': overallScore,
    'skillScores': skillScores,
    'minutesStudied': totalMinutesStudied,
    'practiceSessionsCompleted': totalSessions,
  };
}

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 2), (timer) {
      ref.refresh(userAnalyticsProvider.future);
    });
  }

  @override
  Widget build(BuildContext context) {
    // Trigger data fetching immediately when the widget is built
    final analyticsDataAsyncValue = ref.watch(userAnalyticsProvider);
    final userData = ref.watch(currentUserDataProvider);
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              colorScheme.primary.withOpacity(0.05),
              Colors.white,
            ],
          ),
        ),
        child: SafeArea(
          child: RefreshIndicator(
            onRefresh: () => ref.refresh(userAnalyticsProvider.future),
            child: CustomScrollView(
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.all(16),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      // Welcome Card
                      _buildWelcomeCard(context, userData),
                      const SizedBox(height: 24),

                      // Skill Scores Chart
                      _buildSkillScoresChart(context, analyticsDataAsyncValue),
                      const SizedBox(height: 20),

                      // Stats Cards
                      _buildStatsCards(context, analyticsDataAsyncValue),
                      const SizedBox(height: 20),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildWelcomeCard(BuildContext context, AsyncValue<dynamic> userData) {
    return userData.when(
      data: (user) {
        if (user == null) {
          return const Center(child: Text('User data not found'));
        }
        return Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          color: Theme.of(context).colorScheme.secondaryContainer,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Welcome back,',
                        style: TextStyle(
                          fontSize: 16,
                          color: Theme.of(context).colorScheme.onSecondaryContainer,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        user.email ?? 'User',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.onSecondaryContainer,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Keep up the great progress!',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onSecondaryContainer,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.emoji_events,
                  size: 48,
                  color: Theme.of(context).colorScheme.onSecondaryContainer.withOpacity(0.7),
                ),
              ],
            ),
          ),
        );
      },
      loading: () => const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(child: CircularProgressIndicator()),
        ),
      ),
      error: (error, stack) => Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Center(child: Text('Error loading profile')),
        ),
      ),
    );
  }

  Widget _buildSkillScoresChart(BuildContext context, AsyncValue<Map<String, dynamic>?> analyticsData) {
    final colorScheme = Theme.of(context).colorScheme;
    final skillNames = {
      'reading': 'Reading',
      'writing': 'Writing',
      'listening': 'Listening',
      'speaking': 'Speaking',
    };

    return analyticsData.when(
      data: (analytics) {
        if (analytics == null || analytics['skillScores'] == null) {
          return Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Padding(
              padding: EdgeInsets.all(20),
              child: Center(
                child: Text('No skill data available yet. Complete some practice sessions to see your progress.'),
              ),
            ),
          );
        }

        final skillScores = analytics['skillScores'] as Map<String, dynamic>;
        final skills = skillScores.keys.toList();

        return Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Skill Breakdown',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: colorScheme.onSurface,
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  height: 220,
                  child: BarChart(
                    BarChartData(
                      alignment: BarChartAlignment.spaceAround,
                      maxY: 100,
                      barGroups: List.generate(
                        skills.length,
                            (index) => BarChartGroupData(
                          x: index,
                          barRods: [
                            BarChartRodData(
                              toY: (skillScores[skills[index]] as num).toDouble(),
                              color: _getSkillColor(skills[index], context),
                              width: 20,
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(6),
                                topRight: Radius.circular(6),
                              ),
                            ),
                          ],
                        ),
                      ),
                      titlesData: FlTitlesData(
                        show: true,
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 30,
                            getTitlesWidget: (value, meta) {
                              return Text(
                                value.toInt().toString(),
                                style: TextStyle(
                                  color: colorScheme.onSurfaceVariant,
                                  fontSize: 12,
                                ),
                              );
                            },
                          ),
                        ),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) {
                              final skill = skills[value.toInt()];
                              return Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                  skillNames[skill] ?? skill.capitalize(),
                                  style: TextStyle(
                                    color: colorScheme.onSurfaceVariant,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        rightTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                        topTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                      ),
                      gridData: FlGridData(
                        show: true,
                        drawVerticalLine: false,
                        horizontalInterval: 10,
                        getDrawingHorizontalLine: (value) => FlLine(
                          color: colorScheme.onSurface.withOpacity(0.1),
                          strokeWidth: 1,
                        ),
                      ),
                      borderData: FlBorderData(show: false),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Fixed Wrap for legend
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 16,
                  runSpacing: 8,
                  children: skills
                      .map(
                        (skill) => Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            color: _getSkillColor(skill, context),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          skillNames[skill] ?? skill.capitalize(),
                          style: TextStyle(
                            fontSize: 12,
                            color: colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  )
                      .toList(),
                ),
              ],
            ),
          ),
        );
      },
      loading: () => Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: const SizedBox(
          height: 300,
          child: Center(child: CircularProgressIndicator()),
        ),
      ),
      error: (error, stack) => Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Center(
            child: Text('Error loading skill data: ${error.toString()}'),
          ),
        ),
      ),
    );
  }

  Color _getSkillColor(String skill, BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    switch (skill.toLowerCase()) {
      case 'reading':
        return colorScheme.primary;
      case 'writing':
        return colorScheme.secondary;
      case 'listening':
        return colorScheme.tertiary;
      case 'speaking':
        return colorScheme.error;
      default:
        return colorScheme.primary;
    }
  }

  Widget _buildStatsCards(BuildContext context, AsyncValue<Map<String, dynamic>?> analyticsData) {
    return analyticsData.when(
      data: (analytics) {
        if (analytics == null) {
          return Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Padding(
              padding: EdgeInsets.all(20),
              child: Center(
                child: Text('No progress data available yet. Complete some practice sessions to see your progress.'),
              ),
            ),
          );
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 12),
              child: Text(
                'Your Progress',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    context: context,
                    icon: Icons.timer_outlined,
                    title: 'Study Time',
                    value: '${analytics['minutesStudied'] ?? 0}',
                    unit: 'mins',
                    iconColor: Colors.orange,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildStatCard(
                    context: context,
                    icon: Icons.assignment_turned_in_outlined,
                    title: 'Sessions',
                    value: '${analytics['practiceSessionsCompleted'] ?? 0}',
                    unit: 'completed',
                    iconColor: Colors.green,
                  ),
                ),
              ],
            ),
          ],
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(
        child: Text('Error loading progress data: ${error.toString()}'),
      ),
    );
  }

  Widget _buildStatCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String value,
    required String unit,
    required Color iconColor,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                size: 24,
                color: iconColor,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
                const SizedBox(width: 4),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    unit,
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    if (isEmpty) return this;
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
