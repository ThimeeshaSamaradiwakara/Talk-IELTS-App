import 'package:cloud_firestore/cloud_firestore.dart';

class ExamQuestion {
  final String id;
  final String questionText;
  final String questionType; // 'multiple_choice', 'essay', 'short_answer', etc.
  final List<String>? options; // For multiple choice
  final String? correctAnswer;
  final int points;
  final int timeLimit; // in minutes

  ExamQuestion({
    required this.id,
    required this.questionText,
    required this.questionType,
    this.options,
    this.correctAnswer,
    this.points = 1,
    this.timeLimit = 5,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'questionText': questionText,
      'questionType': questionType,
      'options': options,
      'correctAnswer': correctAnswer,
      'points': points,
      'timeLimit': timeLimit,
    };
  }

  factory ExamQuestion.fromJson(Map<String, dynamic> json) {
    return ExamQuestion(
      id: json['id'] ?? '',
      questionText: json['questionText'] ?? '',
      questionType: json['questionType'] ?? 'multiple_choice',
      options: json['options'] != null ? List<String>.from(json['options']) : null,
      correctAnswer: json['correctAnswer'],
      points: json['points'] ?? 1,
      timeLimit: json['timeLimit'] ?? 5,
    );
  }
}

class Exam {
  final String id;
  final String title;
  final String description;
  final String examType; // 'listening', 'reading', 'writing', 'speaking', 'full'
  final String difficulty; // 'easy', 'medium', 'hard'
  final int totalPoints;
  final int timeLimit; // in minutes
  final List<ExamQuestion> questions;
  final DateTime createdAt;
  final DateTime? updatedAt;

  Exam({
    required this.id,
    required this.title,
    required this.description,
    required this.examType,
    this.difficulty = 'medium',
    required this.totalPoints,
    required this.timeLimit,
    required this.questions,
    DateTime? createdAt,
    this.updatedAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'examType': examType,
      'difficulty': difficulty,
      'totalPoints': totalPoints,
      'timeLimit': timeLimit,
      'questions': questions.map((q) => q.toJson()).toList(),
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
    };
  }

  factory Exam.fromJson(Map<String, dynamic> json) {
    return Exam(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      examType: json['examType'] ?? 'practice',
      difficulty: json['difficulty'] ?? 'medium',
      totalPoints: json['totalPoints'] ?? 0,
      timeLimit: json['timeLimit'] ?? 60,
      questions: json['questions'] != null
          ? (json['questions'] as List)
              .map((q) => ExamQuestion.fromJson(q))
              .toList()
          : [],
      createdAt: (json['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (json['updatedAt'] as Timestamp?)?.toDate(),
    );
  }
}
