import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iel/features/exam/domain/models/exam_model.dart';
import 'presentation/screens/exam_list_screen.dart';
import 'presentation/screens/exam_screen.dart';

class ExamRoutes {
  static const String examList = '/exams';
  static const String exam = '/exam/:id';

  static final routes = [
    GoRoute(
      path: examList,
      builder: (context, state) => const ExamListScreen(),
    ),
    GoRoute(
      path: exam,
      builder: (context, state) {
        final exam = state.extra as dynamic;
        if (exam == null || exam is! Exam) {
          return const Scaffold(
            body: Center(child: Text('Exam not found')),
          );
        }
        return ExamScreen(exam: exam);
      },
    ),
  ];
}
