import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../domain/models/exam_model.dart';
import '../providers/exam_provider.dart';
import '../widgets/generate_exam_dialog.dart';
import 'exam_screen.dart';

class ExamListScreen extends ConsumerWidget {
  const ExamListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final examsAsync = ref.watch(examsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('IELTS Practice Exams'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.invalidate(examsProvider),
          ),
        ],
      ),
      body: examsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(child: Text('Error: $error')),
        data: (exams) {
          if (exams.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('No exams available.'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => _generateNewExam(ref, context),
                    child: const Text('Generate New Exam'),
                  ),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: exams.length,
            itemBuilder: (context, index) {
              final exam = exams[index];
              return _buildExamCard(context, exam, ref);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showGenerateExamDialog(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('New Exam'),
      ),
    );
  }

  Widget _buildExamCard(BuildContext context, Exam exam, WidgetRef ref) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ExamScreen(exam: exam),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      exam.title,
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: _getExamTypeColor(exam.examType).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      exam.examType.toUpperCase(),
                      style: TextStyle(
                        color: _getExamTypeColor(exam.examType),
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                exam.description,
                style: GoogleFonts.roboto(
                  color: Colors.grey[600],
                  fontSize: 14,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _buildInfoChip(
                    Icons.quiz_outlined,
                    '${exam.questions.length} Questions',
                    Colors.blue,
                  ),
                  const SizedBox(width: 8),
                  _buildInfoChip(
                    Icons.timer_outlined,
                    '${exam.timeLimit} min',
                    Colors.orange,
                  ),
                  const SizedBox(width: 8),
                  _buildInfoChip(
                    Icons.star_outline,
                    exam.difficulty.toUpperCase(),
                    _getDifficultyColor(exam.difficulty),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Color _getExamTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'listening':
        return Colors.blue;
      case 'reading':
        return Colors.green;
      case 'writing':
        return Colors.orange;
      case 'speaking':
        return Colors.purple;
      case 'full':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Color _getDifficultyColor(String difficulty) {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return Colors.green;
      case 'medium':
        return Colors.orange;
      case 'hard':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Future<void> _generateNewExam(WidgetRef ref, BuildContext context) async {
    if (!context.mounted) return;
    
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => const GenerateExamDialog(),
    );

    if (result != null && context.mounted) {
      await _generateExamWithParams(
        ref,
        context,
        examType: result['examType'] as String,
        difficulty: result['difficulty'] as String,
        questionCount: result['questionCount'] as int,
      );
    }
  }

  Future<void> _showGenerateExamDialog(BuildContext context, WidgetRef ref) async {
    if (!context.mounted) return;
    
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => const GenerateExamDialog(),
    );

    if (result != null && context.mounted) {
      await _generateExamWithParams(
        ref,
        context,
        examType: result['examType'] as String,
        difficulty: result['difficulty'] as String,
        questionCount: result['questionCount'] as int,
      );
    }
  }
  
  Future<void> _generateExamWithParams(
    WidgetRef ref,
    BuildContext context, {
    required String examType,
    required String difficulty,
    required int questionCount,
  }) async {
    final notifier = ref.read(examGenerationProvider.notifier);
    
    try {
      await notifier.generateExam(
        examType: examType,
        difficulty: difficulty,
        questionCount: questionCount,
      );
      
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Exam generated successfully!')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to generate exam: ${e.toString()}'),
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }
}
