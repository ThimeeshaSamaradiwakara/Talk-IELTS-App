import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../domain/models/exam_model.dart';
import '../providers/exam_provider.dart';
import 'exam_result_screen.dart';

class ExamScreen extends ConsumerStatefulWidget {
  final Exam exam;

  const ExamScreen({super.key, required this.exam});

  @override
  ConsumerState<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends ConsumerState<ExamScreen> {
  final PageController _pageController = PageController();
  late DateTime _startTime;

  @override
  void initState() {
    super.initState();
    _startTime = DateTime.now();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(examSessionProvider.notifier).initialize(widget.exam);
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final examState = ref.watch(examSessionProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.exam.title),
        actions: [
          if (examState.value?.isSubmitted == false)
            Padding(
              padding: const EdgeInsets.only(right: 16.0),
              child: Center(
                child: _buildTimer(),
              ),
            ),
        ],
      ),
      body: examState.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(child: Text('Error: $error')),
        data: (session) {
          if (session.isSubmitted) {
            return ExamResultScreen(
              exam: session.exam,
              score: session.finalScore!,
              totalPoints: session.exam.totalPoints,
              timeSpent: session.timeSpent!,
            );
          }

          final currentQuestion = session.exam.questions[session.currentQuestionIndex];

          return Column(
            children: [
              _buildProgressIndicator(session),
              Expanded(
                child: PageView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  controller: _pageController,
                  itemCount: session.exam.questions.length,
                  itemBuilder: (context, index) {
                    return SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: _buildQuestionCard(currentQuestion, session),
                    );
                  },
                ),
              ),
              _buildNavigationButtons(session),
            ],
          );
        },
      ),
    );
  }

  Widget _buildProgressIndicator(ExamSessionState session) {
    return LinearProgressIndicator(
      value: (session.currentQuestionIndex + 1) / session.exam.questions.length,
      minHeight: 4,
      backgroundColor: Colors.grey[200],
      valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor),
    );
  }

  Widget _buildQuestionCard(ExamQuestion question, ExamSessionState session) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Question ${session.currentQuestionIndex + 1} of ${session.exam.questions.length}',
              style: GoogleFonts.roboto(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              question.questionText,
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 24),
            _buildQuestionInput(question, session),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionInput(ExamQuestion question, ExamSessionState session) {
    final currentAnswer = session.answers[question.id];

    switch (question.questionType) {
      case 'multiple_choice':
        return Column(
          children: (question.options ?? []).map((option) {
            return RadioListTile<String>(
              title: Text(option),
              value: option,
              groupValue: currentAnswer,
              onChanged: (value) {
                ref
                    .read(examSessionProvider.notifier)
                    .answerQuestion(question.id, value);
              },
            );
          }).toList(),
        );
      case 'short_answer':
        return TextField(
          decoration: const InputDecoration(
            labelText: 'Your answer',
            border: OutlineInputBorder(),
          ),
          maxLines: 3,
          onChanged: (value) {
            ref
                .read(examSessionProvider.notifier)
                .answerQuestion(question.id, value);
          },
        );
      case 'essay':
        return TextField(
          decoration: const InputDecoration(
            labelText: 'Write your essay here',
            border: OutlineInputBorder(),
            alignLabelWithHint: true,
          ),
          maxLines: 10,
          onChanged: (value) {
            ref
                .read(examSessionProvider.notifier)
                .answerQuestion(question.id, value);
          },
        );
      default:
        return const Text('Unsupported question type');
    }
  }

  Widget _buildNavigationButtons(ExamSessionState session) {
    final isLastQuestion =
        session.currentQuestionIndex == session.exam.questions.length - 1;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          if (session.currentQuestionIndex > 0)
            OutlinedButton(
              onPressed: () {
                ref.read(examSessionProvider.notifier).previousQuestion();
                _pageController.previousPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
              child: const Text('Previous'),
            )
          else
            const SizedBox(),
          if (!isLastQuestion)
            ElevatedButton(
              onPressed: () {
                ref.read(examSessionProvider.notifier).nextQuestion();
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
              child: const Text('Next'),
            )
          else
            ElevatedButton(
              onPressed: () => _showSubmitConfirmation(session),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
              child: const Text('Submit Exam'),
            ),
        ],
      ),
    );
  }

  Widget _buildTimer() {
    return StreamBuilder<int>(
      stream: Stream.periodic(const Duration(seconds: 1), (i) => i),
      builder: (context, snapshot) {
        final now = DateTime.now();
        final elapsed = now.difference(_startTime);
        final remaining = Duration(
          minutes: widget.exam.timeLimit,
        ).inSeconds - elapsed.inSeconds;

        if (remaining <= 0) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _autoSubmitExam();
          });
        }

        final minutes = (remaining ~/ 60).toString().padLeft(2, '0');
        final seconds = (remaining % 60).toString().padLeft(2, '0');

        return Text(
          '$minutes:$seconds',
          style: GoogleFonts.robotoMono(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: remaining < 60 ? Colors.red : null,
          ),
        );
      },
    );
  }

  Future<void> _showSubmitConfirmation(ExamSessionState session) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Submit Exam'),
        content: Text(
            'You have answered ${session.answers.length} out of ${session.exam.questions.length} questions. Are you sure you want to submit?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
            ),
            child: const Text('Submit'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      _submitExam();
    }
  }

  Future<void> _autoSubmitExam() async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Time\'s Up!'),
        content: const Text('The time for this exam has ended. Your answers will be submitted automatically.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('OK'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      _submitExam();
    }
  }

  void _submitExam() {
    ref.read(examSessionProvider.notifier).submitExam();
  }
}

class ExamResultScreen extends StatelessWidget {
  final Exam exam;
  final int score;
  final int totalPoints;
  final int timeSpent;

  const ExamResultScreen({
    super.key,
    required this.exam,
    required this.score,
    required this.totalPoints,
    required this.timeSpent,
  });

  double get percentage => (score / totalPoints * 100);
  String get timeSpentFormatted {
    final hours = timeSpent ~/ 3600;
    final minutes = (timeSpent % 3600) ~/ 60;
    final seconds = timeSpent % 60;
    
    if (hours > 0) {
      return '${hours}h ${minutes}m ${seconds}s';
    } else if (minutes > 0) {
      return '${minutes}m ${seconds}s';
    } else {
      return '${seconds}s';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Exam Completed!',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 200,
                    height: 200,
                    child: CircularProgressIndicator(
                      value: percentage / 100,
                      strokeWidth: 12,
                      backgroundColor: Colors.grey[200],
                      valueColor: AlwaysStoppedAnimation<Color>(
                        _getScoreColor(percentage),
                      ),
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${percentage.toStringAsFixed(1)}%',
                        style: GoogleFonts.poppins(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: _getScoreColor(percentage),
                        ),
                      ),
                      Text(
                        '$score / $totalPoints',
                        style: GoogleFonts.roboto(
                          fontSize: 18,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 32),
              _buildStatCard(
                icon: Icons.timer_outlined,
                label: 'Time Spent',
                value: timeSpentFormatted,
              ),
              const SizedBox(height: 16),
              _buildStatCard(
                icon: Icons.quiz_outlined,
                label: 'Questions',
                value: '${exam.questions.length} Questions',
              ),
              const SizedBox(height: 16),
              _buildStatCard(
                icon: Icons.star_outline,
                label: 'Difficulty',
                value: exam.difficulty.toUpperCase(),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: const Text('Back to Exams'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, size: 24, color: Colors.blue),
            const SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.roboto(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _getScoreColor(double percentage) {
    if (percentage >= 80) return Colors.green;
    if (percentage >= 60) return Colors.orange;
    return Colors.red;
  }
}
