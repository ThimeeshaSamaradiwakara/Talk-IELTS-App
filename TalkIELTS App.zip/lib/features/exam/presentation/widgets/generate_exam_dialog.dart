import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/models/exam_model.dart';

class GenerateExamDialog extends ConsumerStatefulWidget {
  const GenerateExamDialog({super.key});

  @override
  ConsumerState<GenerateExamDialog> createState() => _GenerateExamDialogState();
}

class _GenerateExamDialogState extends ConsumerState<GenerateExamDialog> {
  String examType = 'writing';
  String difficulty = 'medium';
  int questionCount = 10;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Generate New Exam'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Only show writing exam type
            DropdownButtonFormField<String>(
              value: examType,
              decoration: const InputDecoration(labelText: 'Exam Type'),
              items: const [
                DropdownMenuItem(value: 'writing', child: Text('Writing')),
              ],
              onChanged: null, // Disable changing the exam type
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: difficulty,
              decoration: const InputDecoration(labelText: 'Difficulty'),
              items: const [
                DropdownMenuItem(value: 'easy', child: Text('Easy')),
                DropdownMenuItem(value: 'medium', child: Text('Medium')),
                DropdownMenuItem(value: 'hard', child: Text('Hard')),
              ],
              onChanged: (value) {
                if (value != null) {
                  setState(() => difficulty = value);
                }
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              initialValue: questionCount.toString(),
              decoration: const InputDecoration(
                labelText: 'Number of Questions (1-10)',
                border: OutlineInputBorder(),
                errorText: null,
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                final count = int.tryParse(value) ?? 0;
                setState(() {
                  questionCount = count.clamp(1, 10); // Limit between 1 and 10
                  if (value != questionCount.toString()) {
                    // Update the text field if the value was clamped
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      final controller = TextEditingController(text: questionCount.toString());
                      controller.selection = TextSelection.fromPosition(
                        TextPosition(offset: controller.text.length),
                      );
                      // This would require a GlobalKey to access the TextFormField
                      // For simplicity, we'll just update the value and let the user see it on next build
                    });
                  }
                });
              },
              validator: (value) {
                final count = int.tryParse(value ?? '') ?? 0;
                if (count < 1 || count > 10) {
                  return 'Enter a number between 1 and 10';
                }
                return null;
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            // Validate the question count
            final count = questionCount.clamp(1, 10);
            if (count != questionCount) {
              setState(() => questionCount = count);
              return; // Let the user see the corrected value
            }
            
            Navigator.pop(context, {
              'examType': examType,
              'difficulty': difficulty,
              'questionCount': count,
            });
          },
          child: const Text('Generate'),
        ),
      ],
    );
  }
}
