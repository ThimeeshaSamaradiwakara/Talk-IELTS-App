import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../data/repositories/exam_repository.dart';
import '../../domain/models/exam_model.dart';

// Repository provider
final examRepositoryProvider = Provider<ExamRepository>((ref) {
  final userId = FirebaseAuth.instance.currentUser?.uid;
  return ExamRepository(
    firestore: FirebaseFirestore.instance,
    userId: userId,
  );
});

// Exam list provider
final examsProvider = StreamProvider.autoDispose<List<Exam>>((ref) {
  final repository = ref.watch(examRepositoryProvider);
  return repository.getExams();
});

// Exam generation provider
final examGenerationProvider = StateNotifierProvider.autoDispose<ExamGenerationNotifier, AsyncValue<void>>((ref) {
  final repository = ref.watch(examRepositoryProvider);
  return ExamGenerationNotifier(repository);
});

class ExamGenerationNotifier extends StateNotifier<AsyncValue<void>> {
  final ExamRepository _repository;

  ExamGenerationNotifier(this._repository) : super(const AsyncValue.data(null));

  bool _isDisposed = false;

  @override
  void dispose() {
    _isDisposed = true;
    super.dispose();
  }

  Future<void> generateExam({
    required String examType,
    String difficulty = 'medium',
    int questionCount = 10,
  }) async {
    if (_isDisposed) return;
    
    state = const AsyncValue.loading();
    
    try {
      await _repository.generateExamWithGemini(
        examType: examType,
        difficulty: difficulty,
        questionCount: questionCount,
      );
      
      if (_isDisposed) return;
      state = const AsyncValue.data(null);
    } catch (e, stack) {
      if (_isDisposed) return;
      state = AsyncValue.error(e, stack);
      rethrow;
    }
  }
}

// Exam session provider
final examSessionProvider = StateNotifierProvider.autoDispose<ExamSessionNotifier, AsyncValue<ExamSessionState>>((ref) {
  return ExamSessionNotifier();
});

class ExamSessionNotifier extends StateNotifier<AsyncValue<ExamSessionState>> {
  ExamSessionNotifier() : super(const AsyncValue.loading());

  void initialize(Exam exam) {
    state = AsyncValue.data(ExamSessionState(
      exam: exam,
      currentQuestionIndex: 0,
      answers: {},
      startTime: DateTime.now(),
    ));
  }

  void answerQuestion(String questionId, dynamic answer) {
    state.whenData((session) {
      final answers = Map<String, dynamic>.from(session.answers);
      answers[questionId] = answer;
      state = AsyncValue.data(session.copyWith(answers: answers));
    });
  }

  void nextQuestion() {
    state.whenData((session) {
      if (session.currentQuestionIndex < session.exam.questions.length - 1) {
        state = AsyncValue.data(session.copyWith(
          currentQuestionIndex: session.currentQuestionIndex + 1,
        ));
      }
    });
  }

  void previousQuestion() {
    state.whenData((session) {
      if (session.currentQuestionIndex > 0) {
        state = AsyncValue.data(session.copyWith(
          currentQuestionIndex: session.currentQuestionIndex - 1,
        ));
      }
    });
  }

  void submitExam() {
    // Calculate score and save results
    state.whenData((session) async {
      try {
        final endTime = DateTime.now();
        final timeSpent = endTime.difference(session.startTime).inSeconds;
        
        // Calculate score (in a real app, you'd evaluate answers)
        int score = 0;
        for (final question in session.exam.questions) {
          final userAnswer = session.answers[question.id];
          if (userAnswer == question.correctAnswer) {
            score += question.points;
          }
        }
        
        // Save results
        final repository = ExamRepository(
          firestore: FirebaseFirestore.instance,
          userId: FirebaseAuth.instance.currentUser?.uid,
        );
        
        await repository.saveExamResults(
          examId: session.exam.id,
          score: score,
          totalPoints: session.exam.totalPoints,
          answers: session.answers,
          timeSpent: timeSpent,
        );
        
        // Update state to show results
        state = AsyncValue.data(session.copyWith(
          isSubmitted: true,
          finalScore: score,
          timeSpent: timeSpent,
        ));
        
      } catch (e) {
        state = AsyncValue.error(e, StackTrace.current);
      }
    });
  }
}

class ExamSessionState {
  final Exam exam;
  final int currentQuestionIndex;
  final Map<String, dynamic> answers;
  final DateTime startTime;
  final bool isSubmitted;
  final int? finalScore;
  final int? timeSpent;

  ExamSessionState({
    required this.exam,
    required this.currentQuestionIndex,
    required this.answers,
    required this.startTime,
    this.isSubmitted = false,
    this.finalScore,
    this.timeSpent,
  });

  ExamSessionState copyWith({
    Exam? exam,
    int? currentQuestionIndex,
    Map<String, dynamic>? answers,
    DateTime? startTime,
    bool? isSubmitted,
    int? finalScore,
    int? timeSpent,
  }) {
    return ExamSessionState(
      exam: exam ?? this.exam,
      currentQuestionIndex: currentQuestionIndex ?? this.currentQuestionIndex,
      answers: answers ?? this.answers,
      startTime: startTime ?? this.startTime,
      isSubmitted: isSubmitted ?? this.isSubmitted,
      finalScore: finalScore ?? this.finalScore,
      timeSpent: timeSpent ?? this.timeSpent,
    );
  }
}
