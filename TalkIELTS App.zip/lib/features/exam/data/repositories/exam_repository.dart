import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:uuid/uuid.dart';
import '../../domain/models/exam_model.dart';

// TODO: Move this to environment variables in production
const String _geminiApiKey = 'AIzaSyA-8YhEKXGhDYRep9UDg-WvrL98GPLCCZ8'; // Add your Gemini API key here

class ExamRepository {
  final FirebaseFirestore _firestore;
  final String? userId;

  ExamRepository({required FirebaseFirestore firestore, this.userId})
      : _firestore = firestore;

  // Get all available exams
  Stream<List<Exam>> getExams() {
    return _firestore
        .collection('exams')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Exam.fromJson(doc.data() as Map<String, dynamic>))
            .toList());
  }

  // Get a single exam by ID
  Future<Exam?> getExam(String examId) async {
    try {
      final doc = await _firestore.collection('exams').doc(examId).get();
      if (doc.exists) {
        return Exam.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      print('Error getting exam: $e');
      return null;
    }
  }

  // Save exam results
  Future<void> saveExamResults({
    required String examId,
    required int score,
    required int totalPoints,
    required Map<String, dynamic> answers,
    required int timeSpent,
  }) async {
    if (userId == null) throw Exception('User not authenticated');

    try {
      await _firestore.collection('user_exam_results').add({
        'userId': userId,
        'examId': examId,
        'score': score,
        'totalPoints': totalPoints,
        'percentage': (score / totalPoints * 100).round(),
        'answers': answers,
        'timeSpent': timeSpent, // in seconds
        'completedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error saving exam results: $e');
      rethrow;
    }
  }

  // Generate a new exam using Gemini API
  Future<Exam> generateExamWithGemini({
    required String examType,
    String difficulty = 'medium',
    int questionCount = 10,
  }) async {
    try {
      // Get API key
      if (_geminiApiKey.isEmpty) {
        throw Exception('Gemini API key is not configured. Please add your API key to exam_repository.dart');
      }

      // Initialize the model
      final model = GenerativeModel(
        model: 'gemini-2.0-flash',
        apiKey: _geminiApiKey,
      );

      // Create exam prompt
      final prompt = '''
      Generate an IELTS $examType practice exam with $questionCount questions.
      Difficulty: $difficulty
      
      For each question, include:
      - questionText: The question text
      - questionType: 'multiple_choice', 'essay', or 'short_answer'
      - options: List of options (for multiple choice)
      - correctAnswer: The correct answer
      - points: Points for this question (1-5)
      - timeLimit: Time limit in minutes
      
      Return the response as a JSON object with this structure:
      {
        "title": "IELTS $examType Practice Exam",
        "description": "A practice test for IELTS $examType section",
        "examType": "$examType",
        "difficulty": "$difficulty",
        "totalPoints": 0, // Will be calculated
        "timeLimit": 60, // Total time in minutes
        "questions": [
          {
            "id": "q1",
            "questionText": "...",
            "questionType": "...",
            "options": ["...", "..."], // Only for multiple_choice
            "correctAnswer": "...",
            "points": 1,
            "timeLimit": 5 // Per question time limit in minutes
          },
          // ... more questions
        ]
      }
      ''';

      // Generate content
      final content = Content.text(prompt);
      final response = await model.generateContent(
        [content],
        generationConfig: GenerationConfig(
          temperature: 0.7,
          maxOutputTokens: 4000,
        ),
      );

      if (response.text != null) {
        // Extract JSON from markdown code block if present
        String jsonString = response.text!;
        if (jsonString.trim().startsWith('```json')) {
          // Remove the markdown code block markers
          jsonString = jsonString.replaceAll('```json', '').replaceAll('```', '').trim();
        }
        
        // Parse the JSON response
        final examData = jsonDecode(jsonString) as Map<String, dynamic>;
        
        // Calculate total points
        final questions = (examData['questions'] as List).cast<Map<String, dynamic>>();
        final totalPoints = questions.fold(0, (sum, q) => sum + (q['points'] as int));
        
        // Create exam with calculated total points
        final exam = Exam(
          id: const Uuid().v4(),
          title: examData['title'] as String,
          description: examData['description'] as String,
          examType: examData['examType'] as String,
          difficulty: examData['difficulty'] as String,
          totalPoints: totalPoints,
          timeLimit: examData['timeLimit'] as int,
          questions: questions.map((q) => ExamQuestion(
            id: q['id'] as String,
            questionText: q['questionText'] as String,
            questionType: q['questionType'] as String,
            options: q['options'] != null ? (q['options'] as List).cast<String>() : null,
            correctAnswer: q['correctAnswer'] as String?,
            points: q['points'] as int,
            timeLimit: q['timeLimit'] as int,
          )).toList(),
          createdAt: DateTime.now(),
        );

        // Save to Firestore
        await _firestore.collection('exams').doc(exam.id).set(exam.toJson());
        
        return exam;
      } else {
        throw Exception('No response from the model');
      }
    } catch (e) {
      print('Error generating exam: $e');
      rethrow;
    }
  }
}
