import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iel/features/auth/presentation/providers/auth_provider.dart';
import 'package:iel/features/chat/data/models/chat_message.dart';
import 'package:iel/features/chat/data/services/chat_service.dart';

final chatServiceProvider = Provider<ChatService>((ref) => ChatService());

final chatMessagesProvider = StreamProvider<List<ChatMessage>>((ref) {
  final user = ref.watch(currentUserProvider);
  if (user == null) return Stream.value([]);

  return ref.watch(chatServiceProvider).getChatMessages(user.uid);
});

final sendMessageProvider = Provider.family<Future<void> Function(), String>(
  (ref, message) => () {
    final user = ref.read(currentUserProvider);
    if (user == null) throw Exception('User not authenticated');

    return ref.read(chatServiceProvider).sendMessage(user.uid, message);
  },
);
