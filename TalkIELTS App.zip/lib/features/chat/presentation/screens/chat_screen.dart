import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iel/features/chat/data/models/chat_message.dart';
import 'package:iel/features/chat/presentation/providers/chat_provider.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../../../auth/presentation/providers/auth_provider.dart';

class ChatScreen extends ConsumerStatefulWidget {
  const ChatScreen({super.key});

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> with TickerProviderStateMixin {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();
  bool _isComposing = false;
  late AnimationController _typingIndicatorController;

  final SpeechToText _speechToText = SpeechToText();
  final FlutterTts _flutterTts = FlutterTts();
  bool _isListening = false;
  bool _isSpeaking = false;

  @override
  void initState() {
    super.initState();
    _typingIndicatorController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();

    _messageController.addListener(() {
      final isCurrentlyComposing = _messageController.text.isNotEmpty;
      if (isCurrentlyComposing != _isComposing) {
        setState(() {
          _isComposing = isCurrentlyComposing;
        });
      }
    });

    _initializeSpeechServices();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _typingIndicatorController.dispose();
    _speechToText.stop();
    _flutterTts.stop();
    super.dispose();
  }

  void _initializeSpeechServices() async {
    await _flutterTts.setLanguage('en-US');
    await _flutterTts.setPitch(1.0);
    await _flutterTts.setSpeechRate(0.5);

    _flutterTts.setStartHandler(() {
      setState(() => _isSpeaking = true);
    });

    _flutterTts.setCompletionHandler(() {
      setState(() => _isSpeaking = false);
    });

    _flutterTts.setErrorHandler((error) {
      setState(() => _isSpeaking = false);
      debugPrint('TTS error: $error');
    });

    await _speechToText.initialize(
      onStatus: (status) {
        if (status == 'done') {
          setState(() => _isListening = false);
        }
      },
      onError: (error) {
        setState(() => _isListening = false);
        debugPrint('STT error: $error');
      },
    );
  }

  void _startListening() async {
    if (!_isListening) {
      bool available = await _speechToText.initialize();
      if (available) {
        setState(() => _isListening = true);
        _speechToText.listen(
          onResult: (result) {
            setState(() {
              _messageController.text = result.recognizedWords;
            });
          },
          listenFor: const Duration(seconds: 30),
          pauseFor: const Duration(seconds: 3),
          partialResults: true,
        );
      } else {
        _showSnackBar('Speech recognition not available');
      }
    } else {
      _speechToText.stop();
      setState(() => _isListening = false);

      if (_messageController.text.isNotEmpty) {
        _sendMessage();
      }
    }
  }

  void _stopSpeaking() {
    if (_isSpeaking) {
      _flutterTts.stop();
      setState(() => _isSpeaking = false);
    }
  }

  void _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    _messageController.clear();
    setState(() => _isComposing = false);

    HapticFeedback.mediumImpact();

    _stopSpeaking();

    try {
      await ref.read(sendMessageProvider(message))();
      _scrollToBottom();
    } catch (e) {
      _showSnackBar('Error: ${e.toString()}');
    }
  }

  void _speakMessage(String message) async {
    if (_isSpeaking) {
      await _flutterTts.stop();
      setState(() => _isSpeaking = false);
    } else {
      await _flutterTts.speak(message);
      setState(() => _isSpeaking = true);
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _showSnackBar(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        backgroundColor: Theme.of(context).colorScheme.error,
      ),
    );
  }

  void _clearChat() async {
    try {
      await ref.read(chatServiceProvider).clearChat(
        ref.read(currentUserProvider)?.uid ?? '',
      );

      _showSnackBar('Chat cleared');
    } catch (e) {
      _showSnackBar('Error clearing chat: ${e.toString()}');
    }
  }

  String _getTimeString(DateTime time) {
    return DateFormat('h:mm a').format(time);
  }

  @override
  Widget build(BuildContext context) {
    final messagesAsyncValue = ref.watch(chatMessagesProvider);
    final colorScheme = Theme.of(context).colorScheme;
    final isLightMode = Theme.of(context).brightness == Brightness.light;

    return Scaffold(
      appBar: AppBar(

        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () => _showClearChatDialog(),
            tooltip: 'Clear conversation',
          ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () => _showOptionsBottomSheet(),
            tooltip: 'More options',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isLightMode
                ? [colorScheme.primaryContainer.withOpacity(0.3), colorScheme.surface]
                : [colorScheme.surface, colorScheme.surface],
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: messagesAsyncValue.when(
                data: (messages) => messages.isEmpty
                    ? _buildEmptyState()
                    : _buildMessageList(messages),
                loading: () => const Center(
                  child: CircularProgressIndicator(),
                ),
                error: (error, stack) => Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.error_outline,
                          size: 48,
                          color: colorScheme.error
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Error loading messages',
                        style: TextStyle(color: colorScheme.error),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () {
                          ref.refresh(chatMessagesProvider);
                        },
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            _buildDivider(),
            _buildMessageInput(),
          ],
        ),
      ),
    );
  }

  void _showClearChatDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Conversation'),
        content: const Text('Are you sure you want to clear the entire conversation? This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _clearChat();
            },
            child: const Text('CLEAR'),
          ),
        ],
      ),
    );
  }

  void _showOptionsBottomSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => _buildOptionsMenu(),
    );
  }

  Widget _buildDivider() {
    return Container(
      height: 1,
      color: Theme.of(context).dividerColor.withOpacity(0.1),
    );
  }

  Widget _buildOptionsMenu() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.analytics_outlined),
              title: const Text('IELTS Progress'),
              onTap: () {
                Navigator.of(context).pop();
              },
            ),
            ListTile(
              leading: const Icon(Icons.help_outline),
              title: const Text('IELTS Resources'),
              onTap: () {
                Navigator.of(context).pop();
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const Text('Settings'),
              onTap: () {
                Navigator.of(context).pop();
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('Clear Conversation', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.of(context).pop();
                _showClearChatDialog();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    final theme = Theme.of(context);

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: theme.colorScheme.primary.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.chat_bubble_outline,
                size: 64,
                color: theme.colorScheme.primary,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Your IELTS AI Tutor',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.onBackground,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Ask questions, practice for exams, or get feedback on your writing and speaking!',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyLarge?.copyWith(
                color: theme.colorScheme.onBackground.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 32),
            _buildSuggestionChips(),
          ],
        ),
      ),
    );
  }

  Widget _buildSuggestionChips() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: [
        _buildSuggestionChip('Help me prepare for IELTS speaking'),
        _buildSuggestionChip('Essay writing tips for Task 2'),
        _buildSuggestionChip('Explain IELTS scoring criteria'),
        _buildSuggestionChip('Advanced vocabulary for IELTS'),
      ],
    );
  }

  Widget _buildSuggestionChip(String text) {
    final colorScheme = Theme.of(context).colorScheme;
    return ActionChip(
      label: Text(text),
      backgroundColor: colorScheme.surfaceVariant,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      onPressed: () {
        _messageController.text = text;
        _sendMessage();
      },
    );
  }

  Widget _buildMessageList(List<ChatMessage> messages) {
    Map<String, List<ChatMessage>> messagesByDate = {};

    for (final message in messages) {
      final date = DateFormat('MMMM d, yyyy').format(message.timestamp);
      messagesByDate.putIfAbsent(date, () => []).add(message);
    }

    final sections = messagesByDate.entries.toList()
      ..sort((a, b) => DateFormat('MMMM d, yyyy')
          .parse(a.key)
          .compareTo(DateFormat('MMMM d, yyyy').parse(b.key)));

    return ListView.builder(
      controller: _scrollController,
      reverse: false,
      padding: const EdgeInsets.all(16),
      itemCount: sections.length,
      itemBuilder: (context, sectionIndex) {
        final section = sections[sectionIndex];
        final date = section.key;
        final sectionMessages = section.value..sort((a, b) => a.timestamp.compareTo(b.timestamp));

        return Column(
          children: [
            Center(
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 16),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  date,
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
            ...List.generate(sectionMessages.length, (messageIndex) {
              final message = sectionMessages[messageIndex];
              final showAvatar = messageIndex == 0 || sectionMessages[messageIndex - 1].role != message.role;
              final isLastMessage = sectionIndex == sections.length - 1 && messageIndex == sectionMessages.length - 1;

              return _MessageBubble(
                message: message,
                showAvatar: showAvatar,
                isLastMessage: isLastMessage,
                time: _getTimeString(message.timestamp),
                isTyping: isLastMessage && message.role == MessageRole.assistant && sectionMessages.length == 1,
                typingAnimation: _typingIndicatorController,
                onSpeak: () => _speakMessage(message.content),
                isSpeaking: _isSpeaking,
              );
            }),
          ],
        );
      },
    );
  }

  Widget _buildMessageInput() {
    final colorScheme = Theme.of(context).colorScheme;

    return SafeArea(
      child: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: colorScheme.surfaceVariant.withOpacity(0.5),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Row(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 16.0),
                child: TextField(
                  controller: _messageController,
                  decoration: InputDecoration(
                    hintText: 'Ask anything about IELTS...',
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                    hintStyle: TextStyle(color: colorScheme.onSurfaceVariant.withOpacity(0.7)),
                  ),
                  maxLines: null,
                  keyboardType: TextInputType.multiline,
                  textCapitalization: TextCapitalization.sentences,
                  onSubmitted: (_) {
                    if (_isComposing) {
                      _sendMessage();
                    }
                  },
                ),
              ),
            ),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: _isComposing
                  ? IconButton(
                key: const ValueKey('send'),
                onPressed: _sendMessage,
                icon: Icon(
                  Icons.send_rounded,
                  color: colorScheme.primary,
                ),
              )
                  : IconButton(
                key: const ValueKey('mic'),
                onPressed: _startListening,
                icon: Icon(
                  _isListening ? Icons.stop_circle_rounded : Icons.mic_none_rounded,
                  color: _isListening ? Colors.red : colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final ChatMessage message;
  final bool showAvatar;
  final bool isLastMessage;
  final String time;
  final bool isTyping;
  final bool isSpeaking;
  final Animation<double>? typingAnimation;
  final VoidCallback onSpeak;

  const _MessageBubble({
    required this.message,
    required this.showAvatar,
    required this.isLastMessage,
    required this.time,
    this.isTyping = false,
    this.isSpeaking = false,
    this.typingAnimation,
    required this.onSpeak,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final colorScheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser && showAvatar) ...[
            _buildAvatar(context, isUser),
            const SizedBox(width: 8),
          ] else if (!isUser) ...[
            const SizedBox(width: 40),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (showAvatar && !isUser)
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 4),
                    child: Text(
                      'IELTS Tutor',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: colorScheme.onBackground.withOpacity(0.7),
                      ),
                    ),
                  ),
                Stack(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: isUser
                            ? colorScheme.primary
                            : colorScheme.surfaceVariant,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(isUser || !showAvatar ? 20 : 4),
                          topRight: Radius.circular(!isUser || !showAvatar ? 20 : 4),
                          bottomLeft: const Radius.circular(20),
                          bottomRight: const Radius.circular(20),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      constraints: BoxConstraints(
                        maxWidth: MediaQuery.of(context).size.width * 0.75,
                      ),
                      child: Column(
                        crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                        children: [
                          isTyping
                              ? _buildTypingIndicator(context)
                              : SelectableText(
                            message.content,
                            style: TextStyle(
                              color: isUser
                                  ? colorScheme.onPrimary
                                  : colorScheme.onSurfaceVariant,
                            ),
                          ),
                          if (isUser && message.ieltsScore != null) ...[
                            const SizedBox(height: 8),

                          ],
                          if (message.correctedText != null &&
                              message.correctedText != message.content) ...[
                            const SizedBox(height: 8),
                            Text(
                              'Corrected Text:',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            ),
                            SelectableText(
                              message.correctedText!,
                              style: TextStyle(
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                          if (message.grammarErrors != null && message.grammarErrors!.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              'Grammar Errors:',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            ),
                            ...message.grammarErrors!.map((error) => Text(
                              '- $error',
                              style: TextStyle(
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            )),
                          ],
                          if (message.sentiment != null && message.sentiment!.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              'Sentiment: ${message.sentiment}',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            ),
                            Text(
                              'Confidence Scores:',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            ),
                            Text(
                              'Positive: ${message.confidenceScores?['positive'] ?? 'N/A'}',
                              style: TextStyle(
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            ),
                            Text(
                              'Neutral: ${message.confidenceScores?['neutral'] ?? 'N/A'}',
                              style: TextStyle(
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            ),
                            Text(
                              'Negative: ${message.confidenceScores?['negative'] ?? 'N/A'}',
                              style: TextStyle(
                                color: isUser ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    if (!isUser && !isTyping)
                      Positioned(
                        top: 0,
                        right: 0,
                        child: Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: colorScheme.surface.withOpacity(0.8),
                            shape: BoxShape.circle,
                          ),
                          child: IconButton(
                            padding: EdgeInsets.zero,
                            icon: Icon(
                              isSpeaking ? Icons.stop : Icons.volume_up,
                              size: 16,
                              color: isSpeaking ? Colors.red : colorScheme.primary,
                            ),
                            onPressed: onSpeak,
                          ),
                        ),
                      ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4, left: 4, right: 4),
                  child: Text(
                    isLastMessage ? 'Now • $time' : time,
                    style: TextStyle(
                      fontSize: 10,
                      color: colorScheme.onBackground.withOpacity(0.5),
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (isUser && showAvatar) ...[
            const SizedBox(width: 8),
            _buildAvatar(context, isUser),
          ] else if (isUser) ...[
            const SizedBox(width: 40),
          ],
        ],
      ),
    );
  }


  Widget _buildAvatar(BuildContext context, bool isUser) {
    final theme = Theme.of(context);

    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: isUser
            ? theme.colorScheme.primaryContainer
            : theme.colorScheme.secondaryContainer,
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Icon(
          isUser ? Icons.person : Icons.school,
          size: 16,
          color: isUser
              ? theme.colorScheme.onPrimaryContainer
              : theme.colorScheme.onSecondaryContainer,
        ),
      ),
    );
  }

  Widget _buildTypingIndicator(BuildContext context) {
    return AnimatedBuilder(
      animation: typingAnimation!,
      builder: (context, child) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildDot(context, 0),
            _buildDot(context, 1),
            _buildDot(context, 2),
          ],
        );
      },
    );
  }

  Widget _buildDot(BuildContext context, int index) {
    final colorScheme = Theme.of(context).colorScheme;
    final delay = index * 0.3;
    final position = (typingAnimation!.value - delay) % 1.0;
    final opacity = position < 0.5 ? position * 2 : (1.0 - position) * 2;

    return Container(
      width: 8,
      height: 8,
      margin: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(
        color: colorScheme.onSurfaceVariant.withOpacity(opacity.clamp(0.3, 0.8)),
        shape: BoxShape.circle,
      ),
    );
  }
}
