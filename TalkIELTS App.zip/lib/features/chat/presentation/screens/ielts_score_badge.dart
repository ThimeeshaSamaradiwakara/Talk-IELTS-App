import 'package:flutter/material.dart';

class IeltsScore {
  final double overall;
  final double listening;
  final double reading;
  final double writing;
  final double speaking;

  IeltsScore({
    required this.overall,
    required this.listening,
    required this.reading,
    required this.writing,
    required this.speaking,
  });
}

class IeltsScoreBadge extends StatelessWidget {
  final IeltsScore score;
  final bool detailed;

  const IeltsScoreBadge({
    super.key,
    required this.score,
    this.detailed = false,
  });

  Color _getScoreColor(double score) {
    if (score >= 8.0) return Colors.green;
    if (score >= 6.5) return Colors.blue;
    if (score >= 5.0) return Colors.orange;
    return Colors.red;
  }

  String _getBandDescription(double score) {
    if (score >= 8.5) return 'Expert';
    if (score >= 7.5) return 'Very Good';
    if (score >= 6.5) return 'Good';
    if (score >= 5.5) return 'Moderate';
    if (score >= 4.5) return 'Limited';
    return 'Basic';
  }

  @override
  Widget build(BuildContext context) {
    final overallColor = _getScoreColor(score.overall);

    if (!detailed) {
      // Simple badge with just the overall score
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: overallColor.withOpacity(0.2),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: overallColor, width: 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.analytics, size: 14),
            const SizedBox(width: 4),
            Text(
              'IELTS ${score.overall.toStringAsFixed(1)}',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: overallColor,
              ),
            ),
          ],
        ),
      );
    }

    // Detailed badge with all scores
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.analytics, color: overallColor),
                const SizedBox(width: 8),
                Text(
                  'IELTS Score: ${score.overall.toStringAsFixed(1)}',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: overallColor,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: overallColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _getBandDescription(score.overall),
                    style: TextStyle(
                      fontSize: 12,
                      color: overallColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            // Display detailed scores for each component
            _buildScoreDetailRow('Listening', score.listening),
            _buildScoreDetailRow('Reading', score.reading),
            _buildScoreDetailRow('Writing', score.writing),
            _buildScoreDetailRow('Speaking', score.speaking),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreDetailRow(String label, double score) {
    final color = _getScoreColor(score);
    final description = _getBandDescription(score);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(
            '$label: ',
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            score.toStringAsFixed(1),
            style: TextStyle(
              fontSize: 14,
              color: color,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              description,
              style: TextStyle(
                fontSize: 12,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
