import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iel/features/auth/presentation/providers/auth_provider.dart';
import 'package:iel/features/chat/data/services/chat_service.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

import '../providers/chat_provider.dart';

// Provider for IELTS score history
final ieltsScoresHistoryProvider = FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final user = ref.watch(currentUserProvider);
  if (user == null) return [];

  return ref.watch(chatServiceProvider).getIeltsScoresHistory(user.uid);
});

class IeltsProgressScreen extends ConsumerWidget {
  const IeltsProgressScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scoresHistory = ref.watch(ieltsScoresHistoryProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your IELTS Progress'),
      ),
      body: scoresHistory.when(
        data: (data) => data.isEmpty
            ? _buildEmptyState(context)
            : _buildProgressCharts(context, data),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(
          child: Text('Error loading progress data: ${error.toString()}'),
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.analytics_outlined,
            size: 80,
            color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
          ),
          const SizedBox(height: 24),
          Text(
            'No Progress Data Yet',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Continue practicing with the IELTS tutor to see your progress over time.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onBackground.withOpacity(0.7),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressCharts(BuildContext context, List<Map<String, dynamic>> data) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildOverallProgressCard(context, data),
          const SizedBox(height: 24),
          _buildSkillBreakdownCard(context, data),
          const SizedBox(height: 24),
          _buildRecentMessagesScoreCard(context, data),
        ],
      ),
    );
  }

  Widget _buildOverallProgressCard(BuildContext context, List<Map<String, dynamic>> data) {
    // Extract overall scores from the data
    final overallScores = data.map((entry) =>
        MapEntry(
            entry['timestamp'] as DateTime,
            entry['scores']['overall'] as double
        )
    ).toList();

    // Sort by date
    overallScores.sort((a, b) => a.key.compareTo(b.key));

    // Create data points for the chart
    final spots = overallScores.asMap().entries.map((entry) {
      final index = entry.key.toDouble();
      final score = entry.value.value;
      return FlSpot(index, score);
    }).toList();

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Overall IELTS Progress',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Your estimated IELTS band score over time',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: 200,
              child: spots.length < 2
                  ? Center(
                child: Text(
                  'More data points needed for trend analysis',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              )
                  : LineChart(
                LineChartData(
                  gridData: const FlGridData(show: true),
                  titlesData: FlTitlesData(
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          final index = value.toInt();
                          if (index >= 0 && index < overallScores.length) {
                            final date = overallScores[index].key;
                            return Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Text(
                                DateFormat('MM/dd').format(date),
                                style: const TextStyle(fontSize: 10),
                              ),
                            );
                          }
                          return const Text('');
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          if (value % 1 == 0) {
                            return Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: Text(
                                value.toInt().toString(),
                                style: const TextStyle(fontSize: 10),
                              ),
                            );
                          }
                          return const Text('');
                        },
                        reservedSize: 30,
                      ),
                    ),
                    topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),
                  borderData: FlBorderData(show: true),
                  minX: 0,
                  maxX: (spots.length - 1).toDouble(),
                  minY: 1,
                  maxY: 9,
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      color: Theme.of(context).colorScheme.primary,
                      barWidth: 3,
                      isStrokeCapRound: true,
                      dotData: const FlDotData(show: true),
                      belowBarData: BarAreaData(
                        show: true,
                        color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (spots.isNotEmpty)
              Align(
                alignment: Alignment.center,
                child: _buildCurrentScoreIndicator(
                  context,
                  spots.last.y,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentScoreIndicator(BuildContext context, double score) {
    final displayScore = score.toStringAsFixed(1);
    String levelDescription;
    Color levelColor;

    if (score >= 8.0) {
      levelDescription = 'Very Good';
      levelColor = Colors.green;
    } else if (score >= 6.5) {
      levelDescription = 'Good';
      levelColor = Colors.blue;
    } else if (score >= 5.5) {
      levelDescription = 'Moderate';
      levelColor = Colors.orange;
    } else {
      levelDescription = 'Limited';
      levelColor = Colors.red;
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          'Current estimated score: ',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: levelColor.withOpacity(0.2),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: levelColor),
          ),
          child: RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: '$displayScore ',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: levelColor,
                  ),
                ),
                TextSpan(
                  text: '($levelDescription)',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: levelColor,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSkillBreakdownCard(BuildContext context, List<Map<String, dynamic>> data) {
    // Get the most recent scores
    if (data.isEmpty) return const SizedBox();

    data.sort((a, b) => (b['timestamp'] as DateTime).compareTo(a['timestamp'] as DateTime));
    final latestData = data.first;
    final scores = latestData['scores'] as Map<String, dynamic>;

    final skillScores = {
      'Fluency': scores['fluency'] as double,
      'Pronunciation': scores['pronunciation'] as double,
      'Grammar': scores['grammar'] as double,
      'Vocabulary': scores['vocabulary'] as double,
    };

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Skill Breakdown',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Your latest scores by IELTS speaking skill area',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 24),
            ...skillScores.entries.map((entry) => _buildSkillProgressBar(
              context,
              entry.key,
              entry.value,
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildSkillProgressBar(BuildContext context, String skill, double score) {
    final colorScheme = Theme.of(context).colorScheme;
    final displayScore = score.toStringAsFixed(1);

    Color getBarColor() {
      if (score >= 8.0) return Colors.green;
      if (score >= 6.5) return Colors.blue;
      if (score >= 5.5) return Colors.orange;
      return Colors.red;
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                skill,
                style: Theme.of(context).textTheme.titleSmall,
              ),
              Text(
                displayScore,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: getBarColor(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: score / 9, // 9 is the max IELTS score
              backgroundColor: colorScheme.surfaceVariant,
              color: getBarColor(),
              minHeight: 8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentMessagesScoreCard(BuildContext context, List<Map<String, dynamic>> data) {
    // Sort by date descending to get most recent messages
    data.sort((a, b) => (b['timestamp'] as DateTime).compareTo(a['timestamp'] as DateTime));

    // Take up to 5 most recent messages
    final recentMessages = data.take(5).toList();

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Recent Messages Analysis',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Scores from your recent speaking practice',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 16),
            ...recentMessages.map((message) => _buildMessageScoreItem(context, message)),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageScoreItem(BuildContext context, Map<String, dynamic> message) {
    final timestamp = message['timestamp'] as DateTime;
    final content = message['message'] as String;
    final scores = message['scores'] as Map<String, dynamic>;
    final overall = scores['overall'] as double;

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.message,
                  size: 16,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  DateFormat('MMM d, yyyy - h:mm a').format(timestamp),
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Score: ${overall.toStringAsFixed(1)}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              content.length > 100 ? '${content.substring(0, 100)}...' : content,
              style: Theme.of(context).textTheme.bodyMedium,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}