import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:iel/features/chat/data/models/chat_message.dart';
import 'package:iel/features/chat/data/services/azure_nlp_service.dart';
import 'package:uuid/uuid.dart';

class ChatService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'chats';
  final _uuid = const Uuid();
  final AzureNlpService _azureNlpService = AzureNlpService();

  final _model = GenerativeModel(
    model: 'gemini-2.0-flash',
    apiKey: 'AIzaSyA-8YhEKXGhDYRep9UDg-WvrL98GPLCCZ8',
  );

  Stream<List<ChatMessage>> getChatMessages(String userId) {
    return _firestore
        .collection(_collection)
        .doc(userId)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => ChatMessage.fromJson(doc.data()))
          .toList();
    });
  }

  Future<void> sendMessage(String userId, String content) async {
    try {
      final messageId = _uuid.v4();

      final ieltsScores = await _azureNlpService.analyzeIeltsMessage(content);

      final ieltsScore = IeltsScore(
        fluency: 5.0, // Placeholder, replace with actual calculation
        pronunciation: 5.0, // Placeholder, replace with actual calculation
        grammar: 5.0, // Placeholder, replace with actual calculation
        vocabulary: 5.0, // Placeholder, replace with actual calculation
        overall: 5.0, // Placeholder, replace with actual calculation
      );

      final userMessage = ChatMessage(
        id: messageId,
        content: content,
        role: MessageRole.user,
        timestamp: DateTime.now(),
        userId: userId,
        ieltsScore: ieltsScore,
        correctedText: ieltsScores['correctedText'],
        grammarErrors: ieltsScores['grammarErrors'],
        sentiment: ieltsScores['sentiment'],
        confidenceScores: ieltsScores['confidenceScores'] ?? {
          'positive': 0.0,
          'neutral': 1.0,
          'negative': 0.0,
        },
      );

      await _firestore
          .collection(_collection)
          .doc(userId)
          .collection('messages')
          .doc(messageId)
          .set(userMessage.toJson());

      final response = await _getAIResponse(content);

      final aiMessageId = _uuid.v4();
      final aiMessage = ChatMessage(
        id: aiMessageId,
        content: response,
        role: MessageRole.assistant,
        timestamp: DateTime.now(),
        userId: userId,
      );

      await _firestore
          .collection(_collection)
          .doc(userId)
          .collection('messages')
          .doc(aiMessageId)
          .set(aiMessage.toJson());
    } catch (e) {
      debugPrint('Error sending message: $e');
      rethrow;
    }
  }

  Future<String> _getAIResponse(String userMessage) async {
    try {
      final prompt = '''
You are an IELTS tutor AI assistant. Your role is to help students prepare for their IELTS exam.
The student's message is: $userMessage

Please provide a helpful response that:
1. Corrects any language errors
2. Suggests improvements
3. Explains relevant IELTS concepts
4. Provides examples if needed

Keep your response clear, concise, and focused on IELTS preparation.
''';

      final content = [Content.text(prompt)];
      final response = await _model.generateContent(content);

      String cleanedResponse = response.text?.replaceAll('**', '') ?? 'I apologize, but I was unable to generate a response. Please try again.';

      return cleanedResponse;
    } catch (e) {
      debugPrint('Error getting AI response: $e');
      return 'I apologize, but I encountered an error. Please try again later.';
    }
  }

  Future<void> deleteMessage(String userId, String messageId) async {
    try {
      await _firestore
          .collection(_collection)
          .doc(userId)
          .collection('messages')
          .doc(messageId)
          .delete();
    } catch (e) {
      debugPrint('Error deleting message: $e');
      rethrow;
    }
  }

  Future<void> clearChat(String userId) async {
    try {
      final messages = await _firestore
          .collection(_collection)
          .doc(userId)
          .collection('messages')
          .get();

      final batch = _firestore.batch();
      for (var doc in messages.docs) {
        batch.delete(doc.reference);
      }

      await batch.commit();
    } catch (e) {
      debugPrint('Error clearing chat: $e');
      rethrow;
    }
  }

  Future<List<Map<String, dynamic>>> getIeltsScoresHistory(String userId) async {
    try {
      final messages = await _firestore
          .collection(_collection)
          .doc(userId)
          .collection('messages')
          .where('role', isEqualTo: 'user')
          .where('ieltsScore', isNull: false)
          .orderBy('timestamp')
          .get();

      return messages.docs.map((doc) {
        final data = doc.data();
        final timestamp = (data['timestamp'] as Timestamp).toDate();
        final ieltsScore = IeltsScore.fromJson(data['ieltsScore']);

        return {
          'timestamp': timestamp,
          'message': data['content'],
          'scores': {
            'fluency': ieltsScore.fluency,
            'pronunciation': ieltsScore.pronunciation,
            'grammar': ieltsScore.grammar,
            'vocabulary': ieltsScore.vocabulary,
            'overall': ieltsScore.overall,
          },
          'correctedText': data['correctedText'],
          'grammarErrors': data['grammarErrors'],
          'sentiment': data['sentiment'],
          'confidenceScores': data['confidenceScores'],
        };
      }).toList();
    } catch (e) {
      debugPrint('Error getting IELTS scores history: $e');
      return [];
    }
  }
}
