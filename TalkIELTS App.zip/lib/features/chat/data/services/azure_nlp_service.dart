import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

class AzureNlpService {
  final String _languageToolEndpoint = 'https://api.languagetool.org/v2/check';
  final String _textAnalyticsEndpoint = 'https://ieltstalk.cognitiveservices.azure.com/text/analytics/v3.1/sentiment';
  final String _apiKey = 'FaPYS7hAG5bMjAyzTZTUrFA0c8GqRUBzAME0tALpTacnoaAOEnjEJQQJ99BDACYeBjFXJ3w3AAAaACOGRny5';

  Future<Map<String, dynamic>> analyzeIeltsMessage(String message) async {
    try {
      // 1. Get grammar errors and auto-corrected text
      final grammarCheck = await _checkGrammar(message);
      final correctedText = grammarCheck['correctedText'];

      // 2. Count words and sentences
      final wordCount = _countWords(message);
      final sentenceCount = _countSentences(message);

      // 3. Sentiment Analysis (using corrected text)
      final sentimentAnalysis = await _analyzeSentiment(correctedText);

      return {
        'originalText': message,
        'correctedText': correctedText,
        'sentiment': sentimentAnalysis['sentiment'],
        'confidenceScores': sentimentAnalysis['confidenceScores'],
        'wordCount': wordCount,
        'sentenceCount': sentenceCount,
        'grammarErrors': grammarCheck['errors'],
      };
    } catch (e) {
      debugPrint('Error analyzing IELTS message: $e');
      return _getDefaultScores();
    }
  }

  Future<Map<String, dynamic>> _checkGrammar(String text) async {
    try {
      final data = {
        'text': text,
        'language': 'en-US',
      };

      final response = await http.post(
        Uri.parse(_languageToolEndpoint),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: data,
      );

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        final errors = json['matches'].map((match) =>
        '- ${match['message']} (${match['replacements'][0]['value'] ?? 'no suggestion'})'
        ).toList();

        // Apply corrections in reverse to avoid offset shifting
        var corrected = text;
        final sortedMatches = json['matches'].reversed.toList();
        for (final match in sortedMatches) {
          if (match['replacements'] != null && match['replacements'].isNotEmpty) {
            final suggestion = match['replacements'][0]['value'];
            corrected = corrected.replaceRange(
              match['offset'],
              match['offset'] + match['length'],
              suggestion,
            );
          }
        }

        return {
          'correctedText': corrected,
          'errors': errors,
        };
      } else {
        debugPrint('Grammar check failed: ${response.statusCode} - ${response.body}');
        return {
          'correctedText': text,
          'errors': ['Could not check grammar.'],
        };
      }
    } catch (e) {
      debugPrint('Error in grammar check: $e');
      return {
        'correctedText': text,
        'errors': ['Could not check grammar.'],
      };
    }
  }

  Future<Map<String, dynamic>> _analyzeSentiment(String text) async {
    try {
      final response = await http.post(
        Uri.parse(_textAnalyticsEndpoint),
        headers: {
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key': _apiKey,
        },
        body: jsonEncode({
          'documents': [
            {
              'id': '1',
              'text': text,
              'language': 'en',
            }
          ],
        }),
      );

      if (response.statusCode == 200) {
        final sentimentData = jsonDecode(response.body);
        final document = sentimentData['documents'][0];
        return {
          'sentiment': document['sentiment'] ?? 'neutral',
          'confidenceScores': document['confidenceScores'] ?? {
            'positive': 0.0,
            'neutral': 1.0,
            'negative': 0.0,
          },
        };
      } else {
        debugPrint('Sentiment analysis request failed: ${response.statusCode} - ${response.body}');
        return {};
      }
    } catch (e) {
      debugPrint('Error in sentiment analysis: $e');
      return {};
    }
  }

  int _countWords(String text) {
    return text.trim().split(RegExp(r'\s+')).where((word) => word.isNotEmpty).length;
  }

  int _countSentences(String text) {
    return text.split(RegExp(r'[.!?]+')).where((sentence) => sentence.trim().isNotEmpty).length;
  }

  Map<String, dynamic> _getDefaultScores() {
    return {
      'originalText': '',
      'correctedText': '',
      'sentiment': 'neutral',
      'confidenceScores': {'positive': 0.0, 'neutral': 1.0, 'negative': 0.0},
      'wordCount': 0,
      'sentenceCount': 0,
      'grammarErrors': [],
    };
  }
}