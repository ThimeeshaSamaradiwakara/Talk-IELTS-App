import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageRole { user, assistant }

class ChatMessage {
  final String id;
  final String content;
  final MessageRole role;
  final DateTime timestamp;
  final String userId;
  final IeltsScore? ieltsScore;
  final String? correctedText;
  final List<dynamic>? grammarErrors;
  final String? sentiment;
  final Map<String, dynamic>? confidenceScores;

  ChatMessage({
    required this.id,
    required this.content,
    required this.role,
    required this.timestamp,
    required this.userId,
    this.ieltsScore,
    this.correctedText,
    this.grammarErrors,
    this.sentiment,
    this.confidenceScores,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'] as String,
      content: json['content'] as String,
      role: MessageRole.values.firstWhere(
            (e) => e.toString() == 'MessageRole.${json['role']}',
        orElse: () => MessageRole.user,
      ),
      timestamp: (json['timestamp'] as Timestamp).toDate(),
      userId: json['userId'] as String,
      ieltsScore: json['ieltsScore'] != null
          ? IeltsScore.fromJson(json['ieltsScore'] as Map<String, dynamic>)
          : null,
      correctedText: json['correctedText'] as String?,
      grammarErrors: json['grammarErrors'] as List<dynamic>?,
      sentiment: json['sentiment'] as String?,
      confidenceScores: json['confidenceScores'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'content': content,
      'role': role.toString().split('.').last,
      'timestamp': Timestamp.fromDate(timestamp),
      'userId': userId,
      'ieltsScore': ieltsScore?.toJson(),
      'correctedText': correctedText,
      'grammarErrors': grammarErrors,
      'sentiment': sentiment,
      'confidenceScores': confidenceScores,
    };
  }

  ChatMessage copyWith({
    String? id,
    String? content,
    MessageRole? role,
    DateTime? timestamp,
    String? userId,
    IeltsScore? ieltsScore,
    String? correctedText,
    List<dynamic>? grammarErrors,
    String? sentiment,
    Map<String, dynamic>? confidenceScores,
  }) {
    return ChatMessage(
      id: id ?? this.id,
      content: content ?? this.content,
      role: role ?? this.role,
      timestamp: timestamp ?? this.timestamp,
      userId: userId ?? this.userId,
      ieltsScore: ieltsScore ?? this.ieltsScore,
      correctedText: correctedText ?? this.correctedText,
      grammarErrors: grammarErrors ?? this.grammarErrors,
      sentiment: sentiment ?? this.sentiment,
      confidenceScores: confidenceScores ?? this.confidenceScores,
    );
  }
}

class IeltsScore {
  final double fluency;
  final double pronunciation;
  final double grammar;
  final double vocabulary;
  final double overall;

  IeltsScore({
    required this.fluency,
    required this.pronunciation,
    required this.grammar,
    required this.vocabulary,
    required this.overall,
  });

  factory IeltsScore.fromJson(Map<String, dynamic> json) {
    return IeltsScore(
      fluency: (json['fluency'] as num).toDouble(),
      pronunciation: (json['pronunciation'] as num).toDouble(),
      grammar: (json['grammar'] as num).toDouble(),
      vocabulary: (json['vocabulary'] as num).toDouble(),
      overall: (json['overall'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'fluency': fluency,
      'pronunciation': pronunciation,
      'grammar': grammar,
      'vocabulary': vocabulary,
      'overall': overall,
    };
  }
}
