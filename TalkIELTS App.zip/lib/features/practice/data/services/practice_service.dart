import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:iel/features/practice/data/models/practice_item.dart';

class PracticeService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'practices';

  // Get all practice items for a user, optionally filtered by type
  Stream<List<PracticeItem>> getPracticeItems(String userId, {PracticeType? type}) {
    try {
      Query query = _firestore
          .collection(_collection)
          .where('userId', isEqualTo: userId);

      if (type != null) {
        query = query.where('type', isEqualTo: type.toString().split('.').last);
      }

      return query
          .orderBy('createdAt', descending: true)
          .snapshots()
          .map((snapshot) {
        return snapshot.docs
            .map((doc) => PracticeItem.fromJson({
                  'id': doc.id,
                  ...doc.data() as Map<String, dynamic>,
                }))
            .toList();
      });
    } catch (e) {
      throw Exception('Failed to get practice items: $e');
    }
  }

  // Get a single practice item by ID
  Future<PracticeItem> getPracticeItem(String userId, String itemId) async {
    try {
      final doc = await _firestore
          .collection(_collection)
          .doc(itemId)
          .get();

      if (!doc.exists) {
        throw Exception('Practice item not found');
      }

      return PracticeItem.fromJson({
        'id': doc.id,
        ...doc.data() as Map<String, dynamic>,
      });
    } catch (e) {
      throw Exception('Failed to get practice item: $e');
    }
  }

  // Store a new practice result
  Future<void> storePracticeResult({
    required String userId,
    required String practiceType,
    required String content,
    required double score,
  }) async {
    try {
      final item = {
        'userId': userId,
        'type': practiceType,
        'title': 'Practice Session',
        'description': 'Practice session on ${DateTime.now().toIso8601String()}',
        'difficulty': 'intermediate',
        'estimatedMinutes': 5,
        'targetScore': 7.0,
        'instructions': 'Practice and improve your skills',
        'content': {'text': content},
        'createdAt': FieldValue.serverTimestamp(),
        'isCompleted': true,
        'userScore': score,
      };

      await _firestore.collection(_collection).add(item);
    } catch (e) {
      throw Exception('Failed to store practice result: $e');
    }
  }

  // Get practice statistics
  Future<Map<PracticeType, double>> getPracticeStats(String userId) async {
    try {
      final snapshot = await _firestore
          .collection(_collection)
          .where('userId', isEqualTo: userId)
          .where('isCompleted', isEqualTo: true)
          .get();

      final stats = <PracticeType, List<double>>{};
      
      for (var doc in snapshot.docs) {
        final data = doc.data();
        if (data['type'] != null && data['userScore'] != null) {
          try {
            final type = PracticeType.values.firstWhere(
              (e) => e.toString() == 'PracticeType.${data['type']}',
            );
            final score = (data['userScore'] as num).toDouble();
            stats.putIfAbsent(type, () => []).add(score);
          } catch (e) {
            // Skip invalid entries
            continue;
          }
        }
      }


      // Initialize all practice types with 0.0 if no data exists
      final result = <PracticeType, double>{};
      for (var type in PracticeType.values) {
        result[type] = 0.0;
      }

      // Update with actual stats
      stats.forEach((type, scores) {
        if (scores.isNotEmpty) {
          result[type] = scores.reduce((a, b) => a + b) / scores.length;
        }
      });

      return result;
    } catch (e) {
      throw Exception('Failed to get practice stats: $e');
    }
  }

  // Get recommended practice type based on lowest score
  Future<PracticeType> getRecommendedPractice(String userId) async {
    try {
      final stats = await getPracticeStats(userId);
      
      if (stats.isEmpty) {
        return PracticeType.speaking; // Default to speaking if no history
      }

      // Find the type with the lowest average score
      return stats.entries.reduce((a, b) => a.value < b.value ? a : b).key;
    } catch (e) {
      throw Exception('Failed to get recommended practice: $e');
    }
  }
}
