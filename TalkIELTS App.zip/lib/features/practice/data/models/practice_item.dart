import 'package:cloud_firestore/cloud_firestore.dart';

enum PracticeType {
  reading,
  writing,
  listening,
  speaking
}

enum PracticeDifficulty {
  beginner,
  intermediate,
  advanced
}

class PracticeItem {
  final String id;
  final String title;
  final String description;
  final PracticeType type;
  final PracticeDifficulty difficulty;
  final int estimatedMinutes;
  final double targetScore;
  final String instructions;
  final Map<String, dynamic> content;
  final DateTime createdAt;
  final bool isCompleted;
  final double? userScore;

  PracticeItem({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.difficulty,
    required this.estimatedMinutes,
    required this.targetScore,
    required this.instructions,
    required this.content,
    required this.createdAt,
    this.isCompleted = false,
    this.userScore,
  });

  factory PracticeItem.fromJson(Map<String, dynamic> json) {
    return PracticeItem(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      type: PracticeType.values.firstWhere(
        (e) => e.toString() == 'PracticeType.${json['type']}',
      ),
      difficulty: PracticeDifficulty.values.firstWhere(
        (e) => e.toString() == 'PracticeDifficulty.${json['difficulty']}',
      ),
      estimatedMinutes: json['estimatedMinutes'] as int,
      targetScore: (json['targetScore'] as num).toDouble(),
      instructions: json['instructions'] as String,
      content: json['content'] as Map<String, dynamic>,
      createdAt: (json['createdAt'] as Timestamp).toDate(),
      isCompleted: json['isCompleted'] as bool? ?? false,
      userScore: json['userScore'] != null ? (json['userScore'] as num).toDouble() : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'type': type.toString().split('.').last,
      'difficulty': difficulty.toString().split('.').last,
      'estimatedMinutes': estimatedMinutes,
      'targetScore': targetScore,
      'instructions': instructions,
      'content': content,
      'createdAt': Timestamp.fromDate(createdAt),
      'isCompleted': isCompleted,
      'userScore': userScore,
    };
  }

  PracticeItem copyWith({
    String? id,
    String? title,
    String? description,
    PracticeType? type,
    PracticeDifficulty? difficulty,
    int? estimatedMinutes,
    double? targetScore,
    String? instructions,
    Map<String, dynamic>? content,
    DateTime? createdAt,
    bool? isCompleted,
    double? userScore,
  }) {
    return PracticeItem(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      type: type ?? this.type,
      difficulty: difficulty ?? this.difficulty,
      estimatedMinutes: estimatedMinutes ?? this.estimatedMinutes,
      targetScore: targetScore ?? this.targetScore,
      instructions: instructions ?? this.instructions,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
      isCompleted: isCompleted ?? this.isCompleted,
      userScore: userScore ?? this.userScore,
    );
  }
}
