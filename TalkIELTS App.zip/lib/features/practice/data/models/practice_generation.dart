import 'package:iel/features/practice/data/models/practice_item.dart';

class PracticeGenerationParams {
  final String userId;
  final PracticeType type;
  final PracticeDifficulty difficulty;

  const PracticeGenerationParams({
    required this.userId,
    required this.type,
    required this.difficulty,
  });
}