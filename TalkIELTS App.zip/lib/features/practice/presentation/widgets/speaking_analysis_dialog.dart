import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SpeakingAnalysisDialog extends StatelessWidget {
  final Map<String, dynamic> analysis;
  final VoidCallback onClose;

  const SpeakingAnalysisDialog({
    Key? key,
    required this.analysis,
    required this.onClose,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;
    
    final pronunciation = analysis['pronunciation'] as Map<String, dynamic>? ?? {};
    final grammar = analysis['grammar'] as Map<String, dynamic>? ?? {};
    final fluency = analysis['fluency'] as Map<String, dynamic>? ?? {};
    final overallScore = analysis['overallScore'] as double? ?? 0.0;
    final feedback = analysis['detailedFeedback'] as String? ?? 'No feedback available.';

    return Dialog(
      backgroundColor: theme.scaffoldBackgroundColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 10,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: 600,
          maxHeight: size.height * 0.9,
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Speaking Analysis',
                      style: GoogleFonts.poppins(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: theme.primaryColor,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 24),
                      onPressed: () {
                        Navigator.of(context).pop();
                        onClose();
                      },
                    ),
                  ],
                ),
                
                const SizedBox(height: 16),
                
                // Overall Score Card
                _buildOverallScoreCard(theme, overallScore),
                
                const SizedBox(height: 24),
                
                // Metrics Grid
                LayoutBuilder(
                  builder: (context, constraints) {
                    final isWide = constraints.maxWidth > 600;
                    return isWide
                        ? _buildWideMetrics(theme, pronunciation, grammar, fluency)
                        : _buildNarrowMetrics(theme, pronunciation, grammar, fluency);
                  },
                ),
                
                const SizedBox(height: 24),
                
                // Detailed Feedback
                Text(
                  'Detailed Feedback',
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: theme.primaryColor,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: theme.cardColor,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: theme.dividerColor.withOpacity(0.5),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    feedback,
                    style: GoogleFonts.roboto(
                      fontSize: 15,
                      height: 1.5,
                      color: theme.textTheme.bodyLarge?.color?.withOpacity(0.9),
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                
                // Action Buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                        onClose();
                      },
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      ),
                      child: Text(
                        'CLOSE',
                        style: GoogleFonts.roboto(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                        onClose();
                        // TODO: Implement practice again
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: theme.primaryColor,
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        'PRACTICE AGAIN',
                        style: GoogleFonts.roboto(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOverallScoreCard(ThemeData theme, double score) {
    final scoreColor = _getScoreColor(score);
    
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            scoreColor.withOpacity(0.1),
            scoreColor.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scoreColor.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(
            'Overall Score',
            style: GoogleFonts.poppins(
              fontSize: 16,
              color: theme.textTheme.bodyLarge?.color?.withOpacity(0.8),
            ),
          ),
          const SizedBox(height: 8),
          Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 120,
                height: 120,
                child: CircularProgressIndicator(
                  value: score / 100,
                  strokeWidth: 10,
                  backgroundColor: theme.dividerColor,
                  valueColor: AlwaysStoppedAnimation<Color>(scoreColor),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '${score.toStringAsFixed(1)}',
                    style: GoogleFonts.poppins(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: scoreColor,
                    ),
                  ),
                  Text(
                    _getScoreLabel(score),
                    style: GoogleFonts.roboto(
                      fontSize: 14,
                      color: theme.textTheme.bodyLarge?.color?.withOpacity(0.7),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildWideMetrics(ThemeData theme, Map<String, dynamic> pronunciation, 
      Map<String, dynamic> grammar, Map<String, dynamic> fluency) {
    return Row(
      children: [
        Expanded(child: _buildMetricCard(theme, 'Pronunciation', Icons.record_voice_over, 
            pronunciation['score']?.toDouble() ?? 0.0, pronunciation['suggestions'] ?? [])),
        const SizedBox(width: 16),
        Expanded(child: _buildMetricCard(theme, 'Grammar', Icons.grade, 
            grammar['score']?.toDouble() ?? 0.0, grammar['suggestions'] ?? [])),
        const SizedBox(width: 16),
        Expanded(child: _buildMetricCard(theme, 'Fluency', Icons.speed, 
            fluency['score']?.toDouble() ?? 0.0, fluency['suggestions'] ?? [])),
      ],
    );
  }

  Widget _buildNarrowMetrics(ThemeData theme, Map<String, dynamic> pronunciation, 
      Map<String, dynamic> grammar, Map<String, dynamic> fluency) {
    return Column(
      children: [
        _buildMetricCard(theme, 'Pronunciation', Icons.record_voice_over, 
            pronunciation['score']?.toDouble() ?? 0.0, pronunciation['suggestions'] ?? []),
        const SizedBox(height: 12),
        _buildMetricCard(theme, 'Grammar', Icons.grade, 
            grammar['score']?.toDouble() ?? 0.0, grammar['suggestions'] ?? []),
        const SizedBox(height: 12),
        _buildMetricCard(theme, 'Fluency', Icons.speed, 
            fluency['score']?.toDouble() ?? 0.0, fluency['suggestions'] ?? []),
      ],
    );
  }

  Widget _buildMetricCard(ThemeData theme, String title, IconData icon, 
      double score, List<dynamic> suggestions) {
    final color = _getScoreColor(score);
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: theme.textTheme.titleMedium?.color,
                ),
              ),
              const Spacer(),
              Text(
                '${score.toStringAsFixed(1)}',
                style: GoogleFonts.robotoMono(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          if (suggestions.isNotEmpty) ...[
            const SizedBox(height: 12),
            ...suggestions.take(2).map((suggestion) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.circle, size: 6, color: color),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      suggestion.toString(),
                      style: GoogleFonts.roboto(
                        fontSize: 14,
                        color: theme.textTheme.bodyLarge?.color?.withOpacity(0.8),
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            )).toList(),
          ],
        ],
      ),
    );
  }

  Color _getScoreColor(double score) {
    if (score >= 80) return Colors.green;
    if (score >= 60) return Colors.orange;
    return Colors.red;
  }

  String _getScoreLabel(double score) {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Very Good';
    if (score >= 70) return 'Good';
    if (score >= 60) return 'Fair';
    if (score >= 50) return 'Needs Improvement';
    return 'Needs Work';
  }
}
