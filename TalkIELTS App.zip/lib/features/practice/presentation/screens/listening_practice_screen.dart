import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:iel/shared/providers/azure_nlp_provider.dart';
import '../../../../shared/providers/gemini_provider_new.dart';

@immutable
class Voice {
  final String id;
  final String name;
  final String? locale;

  const Voice({
    required this.id,
    required this.name,
    this.locale,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Voice &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}

final listeningPracticeProvider = StateNotifierProvider<ListeningPracticeNotifier, ListeningPracticeState>((ref) {
  return ListeningPracticeNotifier(
    ref.watch(geminiProvider),
    ref.watch(azureNLPServiceProvider),
  );
});

@immutable
class ListeningPracticeState {
  final bool isLoading;
  final bool isPlaying;
  final String prompt;
  final String userInput;
  final String? errorMessage;
  final String feedback;
  final double? score;
  final String? analysis;
  final String? voiceId;
  final double speechRate;
  final bool isTtsInitialized;
  final List<Voice> availableVoices;

  const ListeningPracticeState({
    this.isLoading = false,
    this.isPlaying = false,
    this.prompt = '',
    this.userInput = '',
    this.errorMessage,
    this.feedback = '',
    this.score,
    this.analysis,
    this.voiceId,
    this.speechRate = 0.5,
    this.isTtsInitialized = false,
    List<Voice>? availableVoices,
  }) : availableVoices = availableVoices ?? const [
          Voice(id: 'en-us-x-tpf-local', name: 'US English Female', locale: 'en-US'),
          Voice(id: 'en-gb-x-gbb-local', name: 'UK English Male', locale: 'en-GB'),
          Voice(id: 'en-au-x-afh-local', name: 'Australian Female', locale: 'en-AU'),
        ];

  factory ListeningPracticeState.initial() {
    return const ListeningPracticeState(
      isLoading: false,
      isPlaying: false,
      prompt: '',
      userInput: '',
      feedback: 'Tap the play button to start',
    );
  }

  ListeningPracticeState copyWith({
    String? prompt,
    String? feedback,
    bool? isLoading,
    bool? isPlaying,
    String? voiceId,
    double? speechRate,
    bool? isTtsInitialized,
    String? userInput,
    List<Voice>? availableVoices,
    double? score,
    String? analysis,
    String? errorMessage,
  }) {
    return ListeningPracticeState(
      prompt: prompt ?? this.prompt,
      feedback: feedback ?? this.feedback,
      isLoading: isLoading ?? this.isLoading,
      isPlaying: isPlaying ?? this.isPlaying,
      voiceId: voiceId ?? this.voiceId,
      speechRate: speechRate ?? this.speechRate,
      isTtsInitialized: isTtsInitialized ?? this.isTtsInitialized,
      userInput: userInput ?? this.userInput,
      availableVoices: availableVoices ?? this.availableVoices,
      score: score ?? this.score,
      analysis: analysis ?? this.analysis,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ListeningPracticeState &&
      other.prompt == prompt &&
      other.userInput == userInput &&
      other.isLoading == isLoading &&
      other.isPlaying == isPlaying &&
      other.score == score &&
      other.feedback == feedback &&
      other.errorMessage == errorMessage;
  }

  @override
  int get hashCode => Object.hash(
    prompt,
    userInput,
    isLoading,
    isPlaying,
    score,
    feedback,
    errorMessage,
  );
}

class ListeningPracticeNotifier extends StateNotifier<ListeningPracticeState> {
  bool _mounted = true;
  bool _isTtsInitialized = false;
  final dynamic _geminiService;
  final dynamic _nlpService;
  final FlutterTts _flutterTts = FlutterTts();

  ListeningPracticeNotifier(
    this._geminiService,
    this._nlpService,
  ) : super(ListeningPracticeState.initial()) {
    _initTts().then((_) {
      if (_mounted) {
        state = state.copyWith(isLoading: true);
        initialize();
      }
    });
  }

  @override
  void dispose() {
    _mounted = false;
    _flutterTts.stop();
    super.dispose();
  }

  bool get mounted => _mounted;
  bool get isTtsInitialized => _isTtsInitialized;

  Voice get currentVoice => state.availableVoices.firstWhere(
        (v) => v.id == state.voiceId,
        orElse: () => state.availableVoices.first,
      );

  Future<void> _initTts() async {
    try {
      debugPrint('Initializing TTS...');
      state = state.copyWith(
        isLoading: true,
        feedback: 'Initializing text-to-speech...',
      );

      // Initialize TTS with error handling
      try {
        await _flutterTts.awaitSpeakCompletion(true);
        _isTtsInitialized = true;
      } catch (e) {
        debugPrint('Error initializing TTS: $e');
        if (_mounted) {
          state = state.copyWith(
            isLoading: false,
            feedback: 'Error initializing text-to-speech. Some features may not work.',
            errorMessage: 'TTS initialization failed: ${e.toString()}',
          );
        }
        return;
      }

      // Get available voices
      List<dynamic>? voices;
      try {
        voices = await _flutterTts.getVoices;
        debugPrint('Available voices: ${voices?.length ?? 0}');
      } catch (e) {
        debugPrint('Error getting voices: $e');
        voices = [];
      }

      // Add default voices
      final List<Voice> allVoicesList = [
        const Voice(id: 'en-us-x-tpf-local', name: 'US English Female', locale: 'en-US'),
        const Voice(id: 'en-gb-x-gbb-local', name: 'UK English Male', locale: 'en-GB'),
        const Voice(id: 'en-au-x-afh-local', name: 'Australian Female', locale: 'en-AU'),
      ];

      // Add system voices if available
      if (voices != null) {
        for (final voice in voices) {
          try {
            final locale = voice['locale'] as String?;
            final name = voice['name'] as String?;
            if (locale != null && name != null) {
              allVoicesList.add(Voice(
                id: name,
                name: name,
                locale: locale,
              ));
            }
          } catch (e) {
            debugPrint('Error processing voice: $e');
          }
        }
      }

      // Remove duplicates
      final uniqueVoices = <String, Voice>{};
      for (var voice in allVoicesList) {
        uniqueVoices[voice.id] = voice;
      }

      final availableVoices = uniqueVoices.values.toList();
      final voiceId = uniqueVoices.keys.contains(state.voiceId)
          ? state.voiceId
          : availableVoices.isNotEmpty ? availableVoices.first.id : '';

      if (_mounted) {
        state = state.copyWith(
          availableVoices: availableVoices,
          voiceId: voiceId,
        );
      }

      // Configure TTS with the selected voice
      await _configureTts();
      _isTtsInitialized = true;
      debugPrint('TTS initialized successfully');
      return;
    } catch (e) {
      debugPrint('Error initializing TTS: $e');
      // Continue with default configuration even if there's an error
      try {
        await _configureTts();
        _isTtsInitialized = true;
      } catch (e) {
        debugPrint('Error in fallback TTS config: $e');
        _isTtsInitialized = false;
      }
    }

    if (_mounted) {
      state = state.copyWith(
        feedback: _isTtsInitialized
            ? 'TTS initialized successfully'
            : 'Warning: TTS initialization had issues',
      );
    }
  }

  Future<void> initialize() async {
    if (!_mounted) return;

    state = state.copyWith(
      isLoading: true,
      feedback: 'Preparing audio...',
      prompt: '',
    );

    try {
      final prompt = await _geminiService.generateListeningPrompt()
          .timeout(const Duration(seconds: 30), onTimeout: () {
            throw TimeoutException('Prompt generation timed out');
          });

      if (!_mounted) return;

      if (prompt.isEmpty) {
        throw Exception('Received empty prompt from service');
      }

      // Remove any text that might be interpreted as commands by TTS
      final cleanPrompt = prompt
          .replaceAll(RegExp(r'[\[\]{}()]'), '') // Remove brackets and parentheses
          .replaceAll(RegExp(r'\*'), '') // Remove asterisks
          .replaceAll(RegExp(r'\n+'), '. ') // Replace multiple newlines with period
          .trim();

      state = state.copyWith(
        prompt: cleanPrompt,
        isLoading: false,
        feedback: 'Ready. Tap the play button to listen.',
      );

      // Auto-play the prompt
      await playPrompt(cleanPrompt);

    } on TimeoutException {
      if (_mounted) {
        state = state.copyWith(
          isLoading: false,
          feedback: 'Audio preparation timed out. Please try again.',
          errorMessage: 'Audio preparation timed out. Please try again.',
        );
      }
    } catch (e) {
      if (_mounted) {
        state = state.copyWith(
          isLoading: false,
          feedback: 'Error preparing audio. Please try again.',
          errorMessage: 'Error preparing audio. Please try again.',
        );
      }
    }
  }

  Future<void> _configureTts() async {
    try {
      if (!_mounted) return;

      final voice = currentVoice;
      debugPrint('Configuring TTS with voice: ${voice.name} (${voice.locale})');

      // Set basic TTS parameters
      await _flutterTts.setSpeechRate(state.speechRate.clamp(0.1, 1.0));
      await _flutterTts.setVolume(1.0);
      await _flutterTts.setPitch(1.0);

      // Set language with fallback
      bool languageSet = false;
      final locale = voice.locale ?? 'en-US';
      try {
        await _flutterTts.setLanguage(locale);
        languageSet = true;
        debugPrint('Set language to: $locale');
      } catch (e) {
        debugPrint('Failed to set language to $locale, trying en-US');
        try {
          await _flutterTts.setLanguage('en-US');
          languageSet = true;
        } catch (e) {
          debugPrint('Failed to set fallback language: $e');
        }
      }

      if (!languageSet) {
        throw Exception('Could not set any language for TTS');
      }

      // Try to set the voice
      bool voiceSet = false;
      try {
        final voiceMap = <String, String>{};
        if (voice.id.isNotEmpty) voiceMap['name'] = voice.id;
        if (voice.locale != null) voiceMap['locale'] = voice.locale!;
        final voiceResult = await _flutterTts.setVoice(voiceMap);
        if (voiceResult == 1) {
          debugPrint('Set voice to: ${voice.name} (${voice.id})');
          voiceSet = true;
        } else {
          debugPrint('Failed to set voice, result code: $voiceResult');
        }
      } catch (e) {
        debugPrint('Error setting voice ${voice.id}: $e');
      }

      // If voice setting failed, try to find a compatible voice
      if (!voiceSet) {
        debugPrint('Trying to find a compatible voice...');
        try {
          final voices = await _flutterTts.getVoices;
          if (voices != null) {
            // Try to find a voice with matching locale
            for (final v in voices) {
              if (v['locale'] == voice.locale) {
                await _flutterTts.setVoice({'name': v['name'], 'locale': v['locale']});
                debugPrint('Set fallback voice to: ${v['name']} (${v['locale']})');
                voiceSet = true;
                break;
              }
            }

            // If still no voice, try any voice with the same language
            if (!voiceSet && voice.locale != null) {
              final lang = voice.locale!.split('-')[0];
              for (final v in voices) {
                final voiceLocale = v['locale'] as String?;
                if (voiceLocale != null && voiceLocale.startsWith(lang)) {
                  await _flutterTts.setVoice({'name': v['name'], 'locale': voiceLocale});
                  debugPrint('Set language fallback voice to: ${v['name']} ($voiceLocale)');
                  voiceSet = true;
                  break;
                }
              }
            }
          }
        } catch (e) {
          debugPrint('Error finding compatible voice: $e');
        }
      }

      if (!voiceSet) {
        debugPrint('Could not set any specific voice, using system default');
      }

      debugPrint('TTS configured successfully');
    } catch (e) {
      debugPrint('Error in _configureTts: $e');
      if (_mounted) {
        state = state.copyWith(
          feedback: 'Error configuring TTS: ${e.toString()}',
        );
      }
      // Try to recover with default settings
      try {
        await _flutterTts.setLanguage('en-US');
        await _flutterTts.setSpeechRate(0.5);
        await _flutterTts.setVolume(1.0);
        await _flutterTts.setPitch(1.0);
      } catch (e) {
        debugPrint('Error in TTS fallback configuration: $e');
      }
    }
  }

  Future<void> playPrompt(String text) async {
    if (!_isTtsInitialized) {
      if (_mounted) {
        state = state.copyWith(
          feedback: 'Text-to-speech not ready. Please wait...',
          errorMessage: 'TTS not initialized',
        );
        // Try to reinitialize TTS
        await _initTts();
      }
      return;
    }

    if (text.isEmpty) {
      if (_mounted) {
        state = state.copyWith(
          feedback: 'No text to speak. Please try again.',
          errorMessage: 'Empty prompt',
        );
      }
      return;
    }

    try {
      state = state.copyWith(
        isPlaying: true,
        feedback: 'Playing audio...',
        errorMessage: null,
      );

      // Configure TTS settings
      await _flutterTts.setSpeechRate(state.speechRate);
      await _flutterTts.setVolume(1.0);
      await _flutterTts.setPitch(1.0);

      // Speak the text
      await _flutterTts.speak(text);

      if (_mounted) {
        state = state.copyWith(
          isPlaying: false,
          feedback: 'Finished playing. Type what you heard.',
        );
      }
    } catch (e) {
      debugPrint('Error playing prompt: $e');
      if (_mounted) {
        state = state.copyWith(
          isPlaying: false,
          feedback: 'Error playing audio. Please try again.',
          errorMessage: 'Playback error: ${e.toString()}',
        );
      }
    }
  }

  void updateVoice(String voiceId) {
    state = state.copyWith(voiceId: voiceId);
    _configureTts();
  }

  Future<void> updateUserInput(String input) async {
    state = state.copyWith(userInput: input);
  }

  Future<void> updateSpeechRate(double rate) async {
    state = state.copyWith(speechRate: rate);
    if (_isTtsInitialized) {
      await _flutterTts.setSpeechRate(rate);
    }
  }

  Future<void> checkAnswer() async {
    if (state.userInput.isEmpty) {
      state = state.copyWith(
        feedback: 'Please enter your answer before checking.',
        errorMessage: 'No input provided',
      );
      return;
    }

    state = state.copyWith(isLoading: true, feedback: 'Analyzing your answer...');
    
    try {
      // First calculate the basic similarity score
      final similarity = _calculateSimilarity(state.prompt, state.userInput);
      final score = (similarity * 100.0).clamp(0.0, 100.0).toDouble();
      
      String feedback;
      String? analysis;
      
      // Try to get detailed analysis if NLP service is available
      try {
        final nlpResult = await _nlpService.analyzeSpeakingTask(state.userInput);
        feedback = nlpResult['corrections']?.toString() ?? _generateBasicFeedback(score.toDouble());
        analysis = nlpResult['analysis']?.toString();
      } catch (e) {
        debugPrint('NLP Analysis Error: $e');
        // Fallback to basic feedback if NLP service fails
        feedback = _generateBasicFeedback(score.toDouble());
      }

      if (_mounted) {
        state = state.copyWith(
          score: score,
          feedback: feedback,
          analysis: analysis,
          isLoading: false,
          errorMessage: null,
        );
      }
    } catch (e, stackTrace) {
      debugPrint('Error in checkAnswer: $e\n$stackTrace');
      if (_mounted) {
        state = state.copyWith(
          feedback: 'We encountered an issue analyzing your answer. Your score is based on keyword matching.',
          isLoading: false,
          errorMessage: 'Analysis error: ${e.toString()}',
        );
      }
    }
  }

  String _generateBasicFeedback(double score) {
    if (score >= 80) {
      return 'Excellent! You got most of the words correct.';
    } else if (score >= 60) {
      return 'Good job! You got many words correct. Keep practicing!';
    } else if (score >= 40) {
      return 'Not bad! Try to listen more carefully to the audio.';
    } else {
      return 'Keep practicing! Try writing down what you hear word by word.';
    }
  }

  double _calculateSimilarity(String original, String input) {
    if (original.isEmpty || input.isEmpty) return 0.0;
    
    final originalWords = original.toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '') // Remove punctuation
        .split(RegExp(r'\s+'))
        .where((word) => word.length > 2) // Ignore very short words
        .toSet(); // Remove duplicates
        
    final inputWords = input.toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(RegExp(r'\s+'))
        .where((word) => word.length > 2)
        .toSet();

    if (originalWords.isEmpty || inputWords.isEmpty) return 0.0;

    // Calculate Jaccard similarity
    final intersection = originalWords.intersection(inputWords).length;
    final union = originalWords.union(inputWords).length;
    
    return union > 0 ? intersection / union : 0.0;
  }

  Future<void> stopPlayback() async {
    await _flutterTts.stop();
    if (_mounted) {
      state = state.copyWith(isPlaying: false);
    }
  }

  Future<void> reset() async {
    state = ListeningPracticeState.initial();
    await initialize();
  }
}

class ListeningPracticeScreen extends ConsumerWidget {
  const ListeningPracticeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(listeningPracticeProvider);
    final notifier = ref.read(listeningPracticeProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Listening Practice'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: state.isLoading ? null : notifier.initialize,
          ),
        ],
      ),
      body: Column(
        children: [
          // Loading indicator or error message
          if (state.isLoading)
            const LinearProgressIndicator()
          else if (state.errorMessage != null)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                state.errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            ),

          // Main content
          Expanded(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Voice selection dropdown
                    if (state.availableVoices.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Select Voice:'),
                            DropdownButton<Voice>(
                              value: state.availableVoices.firstWhere(
                                (v) => v.id == state.voiceId,
                                orElse: () => state.availableVoices.first,
                              ),
                              items: state.availableVoices.map((Voice voice) {
                                return DropdownMenuItem<Voice>(
                                  value: voice,
                                  child: Text(voice.name),
                                );
                              }).toList(),
                              onChanged: (Voice? newValue) {
                                if (newValue != null) {
                                  notifier.updateVoice(newValue.id);
                                }
                              },
                            ),
                          ],
                        ),
                      ),

                    // Speech rate slider
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Speech Rate: ${state.speechRate.toStringAsFixed(1)}'),
                          Slider(
                            value: state.speechRate,
                            min: 0.1,
                            max: 1.0,
                            divisions: 9,
                            label: state.speechRate.toStringAsFixed(1),
                            onChanged: (value) {
                              notifier.updateSpeechRate(value);
                            },
                          ),
                        ],
                      ),
                    ),

                    // Play button
                    Padding(
                      padding: const EdgeInsets.only(bottom: 24.0),
                      child: ElevatedButton.icon(
                        onPressed: (state.isLoading || state.prompt.isEmpty) ? null : () {
                          debugPrint('Play button pressed');
                          if (state.isPlaying) {
                            notifier.stopPlayback();
                          } else {
                            notifier.playPrompt(state.prompt);
                          }
                        },
                        icon: state.isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                ),
                              )
                            : Icon(state.isPlaying ? Icons.stop : Icons.play_arrow),
                        label: Text(state.isPlaying ? 'Stop' : 'Play'),
                      ),
                    ),

                    // Status indicator
                    if (state.isLoading)
                      const Padding(
                        padding: EdgeInsets.only(top: 16.0),
                        child: Text('Preparing audio...'),
                      )
                    else if (state.feedback.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                        child: Text(
                          state.feedback,
                          style: TextStyle(
                            color: state.feedback.contains('Error')
                                ? Colors.red
                                : Theme.of(context).colorScheme.primary,
                            fontStyle: FontStyle.italic,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      )
                    else
                      const Padding(
                        padding: EdgeInsets.only(top: 16.0, bottom: 16.0),
                        child: Text(
                          'Listen to the text and type what you hear:',
                          style: TextStyle(fontSize: 16),
                        ),
                      ),

                    // Debug info (only in debug mode)
                    if (kDebugMode)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16.0),
                        child: Text(
                          'TTS Initialized: ${notifier.isTtsInitialized}\n'
                          'Prompt Length: ${state.prompt.length}\n'
                          'Voice: ${state.voiceId}',
                          style: const TextStyle(fontSize: 10, color: Colors.grey),
                          textAlign: TextAlign.center,
                        ),
                      ),

                    // User input field
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: TextField(
                        onChanged: notifier.updateUserInput,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          hintText: 'Type what you hear...',
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                      ),
                    ),

                    const SizedBox(height: 16.0),

                    // Check answer button
                    Padding(
                      padding: const EdgeInsets.only(bottom: 24.0),
                      child: ElevatedButton(
                        onPressed: state.userInput.isEmpty ? null : notifier.checkAnswer,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                        ),
                        child: const Text('Check Answer', style: TextStyle(fontSize: 16)),
                      ),
                    ),

                    // Show score if available
                    if (state.score != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16.0),
                        child: Text(
                          'Score: ${state.score!.toStringAsFixed(1)}%',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: state.score! >= 70 ? Colors.green : Colors.orange,
                          ),
                        ),
                      ),

                    // Show analysis if available
                    if (state.analysis != null && state.analysis!.isNotEmpty)
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(horizontal: 16.0),
                        padding: const EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Text(
                          state.analysis!,
                          style: const TextStyle(fontSize: 14),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
