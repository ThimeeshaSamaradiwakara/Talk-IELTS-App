import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';
import 'package:googleapis_auth/auth_io.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import './speaking_practice_screen.dart';
import './listening_practice_screen.dart';
import 'package:iel/features/exam/presentation/screens/exam_list_screen.dart';

class PracticeItem {
  final String id;
  final String title;
  final String description;
  final int estimatedMinutes;
  final String instructions;
  final Map<String, dynamic> content;
  final String type;
  final String difficulty;
  final int targetScore;
  final DateTime createdAt;

  PracticeItem({
    required this.id,
    required this.title,
    required this.description,
    required this.estimatedMinutes,
    required this.instructions,
    required this.content,
    required this.type,
    required this.difficulty,
    required this.targetScore,
    required this.createdAt,
  });

  factory PracticeItem.fromJson(Map<String, dynamic> json) {
    return PracticeItem(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      estimatedMinutes: (json['estimatedMinutes'] ?? 0).toInt(),
      instructions: json['instructions'] ?? '',
      content: Map<String, dynamic>.from(json['content'] ?? {}),
      type: json['type'] ?? 'writing',
      difficulty: json['difficulty'] ?? 'medium',
      targetScore: (json['targetScore'] ?? 70).toInt(),
      createdAt: json['createdAt'] != null
          ? (json['createdAt'] is Timestamp
          ? json['createdAt'].toDate()
          : DateTime.parse(json['createdAt'].toString()))
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'estimatedMinutes': estimatedMinutes,
      'instructions': instructions,
      'content': content,
      'type': type,
      'difficulty': difficulty,
      'targetScore': targetScore,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}

final geminiModelProvider = FutureProvider<GenerativeModel>((ref) async {
  final serviceAccountJson = await rootBundle.loadString('assets/service_account.json');
  final serviceAccountCredentials = ServiceAccountCredentials.fromJson(jsonDecode(serviceAccountJson));

  final authClient = await obtainAccessCredentialsViaServiceAccount(
    serviceAccountCredentials,
    [
      "https://www.googleapis.com/auth/generative-language",
      "https://www.googleapis.com/auth/generative-language.tuning",
      "https://www.googleapis.com/auth/generative-language.tuning.readonly",
      "https://www.googleapis.com/auth/generative-language.retriever",
      "https://www.googleapis.com/auth/generative-language.retriever.readonly"
    ],
    http.Client(),
  );

  return GenerativeModel(authClient: authClient);
});

class GenerativeModel {
  final AccessCredentials authClient;

  GenerativeModel({required this.authClient});

  Future<ContentResponse> generateContent(String prompt) async {
    final client = authenticatedClient(http.Client(), authClient);

    final url = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent');

    final response = await client.post(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'contents': [
          {'parts': [{'text': prompt}]}
        ]
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      try {
        final candidates = data['candidates'] as List;
        if (candidates.isNotEmpty) {
          final parts = candidates[0]['content']['parts'] as List;
          if (parts.isNotEmpty) {
            return ContentResponse(text: parts[0]['text'] ?? '');
          }
        }
        return ContentResponse(text: '');
      } catch (e) {
        throw Exception('Failed to parse Gemini response: $e');
      }
    } else {
      print('Error: ${response.statusCode}, ${response.reasonPhrase}');
      print('Response body: ${response.body}');
      throw Exception('Error ${response.statusCode}: ${response.reasonPhrase}');
    }
  }

  Future<Map<String, dynamic>> evaluateAnswerWithFeedback(String question, String correctAnswer, String userAnswer) async {
    final prompt = """
    Evaluate the following answer for the question: "$question".

    Correct Answer: $correctAnswer

    User Answer: $userAnswer

    Provide a score from 0-100 and detailed feedback for improvement.
    Return in JSON format: {"score": number, "feedback": "detailed feedback"}
    """;

    final response = await generateContent(prompt);

    // Parse JSON from response text
    final jsonRegex = RegExp(r'\{[\s\S]*\}');
    final jsonMatch = jsonRegex.firstMatch(response.text);

    if (jsonMatch == null) {
      throw Exception('Failed to parse evaluation response');
    }

    final jsonStr = jsonMatch.group(0);
    try {
      final resultJson = jsonDecode(jsonStr!);
      return {
        'score': (resultJson['score'] as num).toDouble(),
        'feedback': resultJson['feedback'] as String,
      };
    } catch (e) {
      throw Exception('Failed to parse evaluation JSON: $e');
    }
  }
}

class ContentResponse {
  final String text;

  ContentResponse({required this.text});

  factory ContentResponse.fromJson(Map<String, dynamic> json) {
    return ContentResponse(
      text: json['text'] ?? '',
    );
  }
}

// Provider for user practice items
final userPracticeItemsProvider = StreamProvider<List<PracticeItem>>((ref) {
  final user = ref.watch(currentUserProvider);
  if (user == null) return Stream.value([]);

  return FirebaseFirestore.instance
      .collection('practice_items')
      .where('assignedUserIds', arrayContains: user.uid)
      .snapshots()
      .map((snapshot) => snapshot.docs
      .map((doc) {
    // Create a PracticeItem directly from the document data
    final data = doc.data();
    // Ensure id is set from the document id if not present in the data
    data['id'] = doc.id;
    return PracticeItem.fromJson(data);
  })
      .toList());
});

// Provider for creating practice items
final practiceItemsRepositoryProvider = Provider<PracticeItemsRepository>((ref) {
  return PracticeItemsRepository(ref);
});

class PracticeItemsRepository {
  final ProviderRef ref;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  PracticeItemsRepository(this.ref);

  Future<void> fetchAndCreatePracticeItems() async {
    final user = ref.read(currentUserProvider);
    if (user == null) return;

    // Fetch practice items from QuizAPI
    final quizApiUrl = Uri.parse(
        'https://quizapi.io/api/v1/questions?apiKey=AYWwpF8mHQjLj1ooigw2bVfszzEaG8lUyr043F03&limit=10'
    );
    final response = await http.get(quizApiUrl);

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);

      for (var item in data) {
        // Filter only English-related categories
        final category = item['category']?.toString().toLowerCase() ?? '';
        if (category.contains('english') || category.contains('language') || category.contains('grammar')) {
          final practiceItem = PracticeItem(
            id: const Uuid().v4(),
            title: item['question'] ?? 'No Title',
            description: category.isNotEmpty ? category : 'English',
            estimatedMinutes: 15,
            instructions: 'Answer the following question.',
            content: {
              'prompt': item['question'] ?? '',
              'correct_answer': item['correct_answer'] ?? '',
            },
            type: 'quiz',
            difficulty: item['difficulty'] ?? 'medium',
            targetScore: 70,
            createdAt: DateTime.now(),
          );

          // Add practice item to Firestore
          await _firestore.collection('practice_items').add({
            ...practiceItem.toJson(),
            'assignedUserIds': [user.uid],
          });
        }
      }
    } else {
      throw Exception('Failed to fetch practice items from QuizAPI');
    }
  }

  // New method to regenerate practice items
  Future<void> regeneratePracticeItems() async {
    final user = ref.read(currentUserProvider);
    if (user == null) return;

    // Optional: Delete existing practice items for this user
    final existingItems = await _firestore
        .collection('practice_items')
        .where('assignedUserIds', arrayContains: user.uid)
        .get();

    final batch = _firestore.batch();
    for (var doc in existingItems.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();

    // Now fetch and create new items
    await fetchAndCreatePracticeItems();
  }

  // Alternative method using Gemini to create practice items
  Future<void> generatePracticeItemsWithGemini() async {
    final user = ref.read(currentUserProvider);
    if (user == null) return;

    final geminiModel = await ref.read(geminiModelProvider.future);

    final prompt = """
    Generate 3 English language quiz questions with the following structure for each:
    1. A question that tests English knowledge or skills (grammar, vocabulary, comprehension, etc.)
     2. Include only a single correct answer (do NOT provide multiple choice options).
    3. Question difficulty (easy/medium/hard)
    4. Category (e.g., Grammar, Vocabulary, Reading Comprehension, Writing)

    Return the response in JSON array format:
    [
      {
        "question": "question text",
        "correct_answer": "correct answer",
        "difficulty": "medium",
        "category": "Grammar"
      },
      ...
    ]
    """;

    try {
      final response = await geminiModel.generateContent(prompt);

      // Parse JSON from response text
      final jsonRegex = RegExp(r'\[[\s\S]*\]');
      final jsonMatch = jsonRegex.firstMatch(response.text);

      if (jsonMatch == null) {
        throw Exception('Failed to parse questions from Gemini');
      }

      final jsonStr = jsonMatch.group(0);
      final List<dynamic> questions = jsonDecode(jsonStr!);

      for (var item in questions) {
        final practiceItem = PracticeItem(
          id: const Uuid().v4(),
          title: item['question'] ?? 'No Title',
          description: item['category'] ?? 'English',
          estimatedMinutes: 15,
          instructions: 'Answer the following question.',
          content: {
            'prompt': item['question'] ?? '',
            'correct_answer': item['correct_answer'] ?? '',
          },
          type: 'quiz',
          difficulty: item['difficulty'] ?? 'medium',
          targetScore: 70,
          createdAt: DateTime.now(),
        );

        // Add practice item to Firestore
        await _firestore.collection('practice_items').add({
          ...practiceItem.toJson(),
          'assignedUserIds': [user.uid],
        });
      }
    } catch (e) {
      throw Exception('Failed to generate practice items with Gemini: $e');
    }
  }
}

class WritingPracticeScreen extends ConsumerStatefulWidget {
  const WritingPracticeScreen({super.key});

  @override
  ConsumerState<WritingPracticeScreen> createState() => _WritingPracticeScreenState();
}

class _WritingPracticeScreenState extends ConsumerState<WritingPracticeScreen> {
  final _textController = TextEditingController();
  bool _isSubmitting = false;
  bool _isRegenerating = false;
  String? _error;
  PracticeItem? _selectedItem;
  double? _currentScore;
  String? _feedback;
  int _remainingSeconds = 0;
  bool _timerActive = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _checkAndCreateSampleItems();
  }

  Future<void> _checkAndCreateSampleItems() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Fetch and create practice items
      await ref.read(practiceItemsRepositoryProvider).fetchAndCreatePracticeItems();
    } catch (e) {
      print('Error creating practice items: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _regeneratePracticeItems() async {
    setState(() {
      _isRegenerating = true;
      _error = null;
    });

    try {
      // Use Gemini instead of QuizAPI
      await ref.read(practiceItemsRepositoryProvider).generatePracticeItemsWithGemini();

      // Reset UI state
      setState(() {
        _selectedItem = null;
        _textController.clear();
        _currentScore = null;
        _feedback = null;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to regenerate practice items: ${e.toString()}';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isRegenerating = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  void _startTimer() {
    if (_selectedItem != null) {
      setState(() {
        _remainingSeconds = _selectedItem!.estimatedMinutes * 60;
        _timerActive = true;
      });

      // Update timer every second
      Future.doWhile(() async {
        await Future.delayed(const Duration(seconds: 1));
        if (!mounted || !_timerActive) return false;

        setState(() {
          if (_remainingSeconds > 0) {
            _remainingSeconds--;
          } else {
            _timerActive = false;
          }
        });

        return _timerActive && _remainingSeconds > 0;
      });
    }
  }

  String _formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  Future<void> _submitAnswer() async {
    if (_selectedItem == null) {
      setState(() {
        _error = 'Please select a practice item first';
      });
      return;
    }

    if (_textController.text.trim().isEmpty) {
      setState(() {
        _error = 'Please write your answer before submitting';
      });
      return;
    }

    setState(() {
      _isSubmitting = true;
      _error = null;
      _timerActive = false;
    });

    try {
      final answer = _textController.text.trim();
      final user = ref.read(currentUserProvider);

      if (user == null) {
        throw Exception('User not logged in');
      }

      // Generate analysis and score with Gemini
      final geminiModel = await ref.read(geminiModelProvider.future);
      final result = await geminiModel.evaluateAnswerWithFeedback(
          _selectedItem!.content['prompt'],
          _selectedItem!.content['correct_answer'],
          answer
      );

      final score = result['score'] as double;
      final feedback = result['feedback'] as String;

      // Store results in Firestore
      await _storeResultsInFirestore(answer, score, feedback);

      setState(() {
        _currentScore = score;
        _feedback = feedback;
        _isSubmitting = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isSubmitting = false;
      });
    }
  }

  Future<void> _storeResultsInFirestore(String answer, double score, String feedback) async {
    final user = ref.read(currentUserProvider);
    if (user == null) {
      throw Exception('User not logged in');
    }

    final firestore = FirebaseFirestore.instance;

    // Prepare the data to be stored
    final testResultData = {
      'userId': user.uid,
      'practiceId': _selectedItem!.id,
      'answer': answer,
      'score': score,
      'feedback': feedback,
      'targetScore': _selectedItem!.targetScore,
      'timestamp': FieldValue.serverTimestamp(),
      'completed': true,
      'timeTaken': _selectedItem!.estimatedMinutes * 60 - _remainingSeconds,
      'testDetails': {
        'title': _selectedItem!.title,
        'description': _selectedItem!.description,
        'estimatedMinutes': _selectedItem!.estimatedMinutes,
        'instructions': _selectedItem!.instructions,
        'content': _selectedItem!.content,
        'type': _selectedItem!.type,
        'difficulty': _selectedItem!.difficulty,
        'createdAt': _selectedItem!.createdAt.toIso8601String(),
      }
    };

    try {
      // Add the test result to the 'practice_results' collection
      await firestore.collection('practice_results').add(testResultData);
      print('Test result stored successfully');
    } catch (e) {
      print('Error storing test result: $e');
      throw Exception('Failed to store test result');
    }
  }

  void _selectPracticeItem(PracticeItem item) {
    setState(() {
      _selectedItem = item;
      _textController.clear();
      _currentScore = null;
      _feedback = null;
      _error = null;
      _timerActive = false;
    });

    // Start timer after a short delay
    Future.delayed(const Duration(milliseconds: 500), _startTimer);
  }

  void _startNewPractice() {
    setState(() {
      _selectedItem = null;
      _textController.clear();
      _currentScore = null;
      _feedback = null;
      _error = null;
      _timerActive = false;
    });
  }

  void _navigateToSpeakingPractice() {
    if (!mounted) return;
    
    // Stop any ongoing operations
    if (_timerActive) {
      setState(() {
        _timerActive = false;
      });
    }
    
    // Navigate using push instead of pushReplacement
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const SpeakingPracticeScreen(),
      ),
    );
  }

  void _navigateToListeningPractice() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ListeningPracticeScreen(),
      ),
    );
  }

  void _navigateToExams() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const ExamListScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final practiceItems = ref.watch(userPracticeItemsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Writing Practice'),
        actions: [
          // Exam navigation
          IconButton(
            icon: const Icon(Icons.add_comment),
            onPressed: _navigateToExams,
            tooltip: 'Take an Exam',
          ),
          // Listening practice navigation
          IconButton(
            icon: const Icon(Icons.headphones),
            onPressed: _navigateToListeningPractice,
            tooltip: 'Listening Practice',
          ),
          // Speaking practice navigation
          IconButton(
            icon: const Icon(Icons.mic),
            onPressed: _navigateToSpeakingPractice,
            tooltip: 'Speaking Practice',
          ),
          // Refresh button (only shown when an item is selected)
          if (_selectedItem != null)
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: _startNewPractice,
              tooltip: 'Start New Practice',
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : practiceItems.when(
        data: (items) {
          if (items.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('No practice items available'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _regeneratePracticeItems,
                    child: const Text('Generate New Practice Items'),
                  ),
                ],
              ),
            );
          }

          if (_selectedItem == null) {
            return _buildPracticeItemList(items);
          } else {
            return _buildPracticeSession();
          }
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Error: ${error.toString()}'),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _checkAndCreateSampleItems,
                child: const Text('Try Again'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPracticeItemList(List<PracticeItem> items) {
    return Column(
      children: [
        // New regenerate button
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: ElevatedButton.icon(
            onPressed: _isRegenerating ? null : _regeneratePracticeItems,
            icon: _isRegenerating
                ? const SizedBox(
                height: 16,
                width: 16,
                child: CircularProgressIndicator(strokeWidth: 2)
            )
                : const Icon(Icons.refresh),
            label: Text(_isRegenerating ? 'Regenerating...' : 'Generate New Practice Items'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
              minimumSize: const Size(double.infinity, 50),
            ),
          ),
        ),

        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Card(
              color: Theme.of(context).colorScheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Row(
                  children: [
                    Icon(Icons.error_outline,
                        color: Theme.of(context).colorScheme.error),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(_error!,
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.onErrorContainer),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(
                    color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
                    width: 1,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        style: Theme.of(context).textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        item.description,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _buildInfoChip(
                            Icons.timer,
                            '${item.estimatedMinutes} min',
                            Theme.of(context).colorScheme.primaryContainer,
                          ),
                          const SizedBox(width: 8),
                          _buildInfoChip(
                            Icons.star,
                            'Target: ${item.targetScore}',
                            Theme.of(context).colorScheme.secondaryContainer,
                          ),
                          const SizedBox(width: 8),
                          _buildDifficultyChip(item.difficulty),
                        ],
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          onPressed: () => _selectPracticeItem(item),
                          style: FilledButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: const Text('Start Practice'),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDifficultyChip(String difficulty) {
    Color chipColor;
    switch (difficulty.toLowerCase()) {
      case 'easy':
        chipColor = Colors.green;
        break;
      case 'medium':
        chipColor = Colors.orange;
        break;
      case 'hard':
        chipColor = Colors.red;
        break;
      default:
        chipColor = Colors.blue;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: chipColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: chipColor),
      ),
      child: Text(
        difficulty,
        style: TextStyle(
          color: chipColor,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label, Color backgroundColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 4),
          Text(
            label,
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildPracticeSession() {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              _selectedItem!.title,
                              style: Theme.of(context).textTheme.titleLarge!.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          _buildTimerDisplay(),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _selectedItem!.description,
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      const SizedBox(height: 16),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          _buildInfoChip(
                            Icons.timer,
                            '${_selectedItem!.estimatedMinutes} min',
                            Theme.of(context).colorScheme.primaryContainer,
                          ),
                          _buildInfoChip(
                            Icons.star,
                            'Target: ${_selectedItem!.targetScore}',
                            Theme.of(context).colorScheme.secondaryContainer,
                          ),
                          _buildDifficultyChip(_selectedItem!.difficulty),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surfaceVariant,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: Theme.of(context).colorScheme.outline.withOpacity(0.5),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Instructions:',
                              style: Theme.of(context).textTheme.titleMedium!.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _selectedItem!.instructions,
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                            if (_selectedItem!.content['prompt'] != null) ...[
                              const SizedBox(height: 16),
                              Text(
                                'Question:',
                                style: Theme.of(context).textTheme.titleMedium!.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.5),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                                  ),
                                ),
                                child: Text(
                                  _selectedItem!.content['prompt'] as String,
                                  style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                                    fontStyle: FontStyle.italic,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Your Answer:',
                        style: Theme.of(context).textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _textController,
                        maxLines: null,
                        minLines: 8,
                        decoration: InputDecoration(
                          hintText: 'Write your answer here...',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          errorText: _error,
                          contentPadding: const EdgeInsets.all(16),
                          filled: true,
                          fillColor: Theme.of(context).colorScheme.surface,
                        ),
                        style: Theme.of(context).textTheme.bodyMedium,
                        enabled: _currentScore == null,
                      ),
                      const SizedBox(height: 8),
                      if (_textController.text.isNotEmpty)
                        Text(
                          'Word count: ${_countWords(_textController.text)}',
                          style: Theme.of(context).textTheme.bodySmall,
                          textAlign: TextAlign.end,
                        ),
                    ],
                  ),
                ),
              ),
              if (_currentScore != null && _feedback != null) ...[
                const SizedBox(height: 20),
                Card(
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  color: Theme.of(context).colorScheme.surfaceVariant,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Feedback:',
                          style: Theme.of(context).textTheme.titleMedium!.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _feedback!,
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Score: $_currentScore',
                          style: Theme.of(context).textTheme.titleMedium!.copyWith(
                            fontWeight: FontWeight.bold,
                            color: _currentScore! >= _selectedItem!.targetScore
                                ? Colors.green
                                : Colors.red,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: FilledButton(
            onPressed: _isSubmitting ? null : _submitAnswer,
            style: FilledButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              minimumSize: const Size(double.infinity, 50),
            ),
            child: Text(_isSubmitting ? 'Submitting...' : 'Submit Answer'),
          ),
        ),
      ],
    );
  }

  Widget _buildTimerDisplay() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.timer, size: 16, color: Theme.of(context).colorScheme.onPrimaryContainer),
          const SizedBox(width: 4),
          Text(
            _formatTime(_remainingSeconds),
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).colorScheme.onPrimaryContainer,
            ),
          ),
        ],
      ),
    );
  }

  int _countWords(String text) {
    return text.trim().split(RegExp(r'\s+')).length;
  }
}
