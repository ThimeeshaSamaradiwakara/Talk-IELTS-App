import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../widgets/speaking_analysis_dialog.dart';
import '../../../../shared/providers/azure_nlp_provider_new.dart';

class SpeakingPracticeScreen extends ConsumerStatefulWidget {
  const SpeakingPracticeScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<SpeakingPracticeScreen> createState() =>
      _SpeakingPracticeScreenState();
}

class _SpeakingPracticeScreenState extends ConsumerState<SpeakingPracticeScreen> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final TextEditingController _textController = TextEditingController();
  String _text = '';
  bool _isListening = false;
  bool _isAnalyzing = false;
  Timer? _timer;
  Timer? _countdownTimer;
  int _secondsRemaining = 120; // 2 minutes
  
  // Audio recording state
  List<double> _audioSamples = [];
  bool _isRecording = false;
  
  // Analysis results are now used directly in the dialog without storing in state

  @override
  void initState() {
    super.initState();
    _initializeSpeech();
    _startCountdownTimer();
  }

  @override
  void dispose() {
    _textController.dispose();
    _timer?.cancel();
    _countdownTimer?.cancel();
    _speech.stop();
    super.dispose();
  }
  
  void _startCountdownTimer() {
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsRemaining > 0 && _isListening) {
        setState(() => _secondsRemaining--);
      } else if (_isListening) {
        _stopListening();
      }
    });
  }

  Future<void> _initializeSpeech() async {
    await _speech.initialize();
    setState(() {});
  }

  Future<void> _startListening() async {
    if (!_speech.isAvailable) return;

    setState(() {
      _isListening = true;
      _isRecording = true;
      _text = '';
      _textController.clear();
      _secondsRemaining = 120;
      _audioSamples = [];
    });

    // Start audio recording simulation
    _timer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (_isRecording) {
        // Simulate audio samples (in a real app, this would come from the microphone)
        _audioSamples.add(0.5);
      }
    });

    await _speech.listen(
      onResult: (result) {
        setState(() {
          _text = result.recognizedWords;
          _textController.text = _text;
        });
      },
    );

    // Timer for auto-stopping after 2 minutes is handled by _startCountdownTimer
  }

  Future<void> _stopListening() async {
    await _speech.stop();
    setState(() {
      _isListening = false;
      _isRecording = false;
    });
    _timer?.cancel();
    
    // Start analysis if we have some text
    if (_text.trim().isNotEmpty) {
      _analyzeSpeech();
    }
  }

  Future<void> _analyzeSpeech() async {
    if (_text.trim().isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No speech detected. Please try speaking again.')),
        );
      }
      return;
    }

    setState(() => _isAnalyzing = true);

    try {
      // Convert audio samples to base64 (simplified)
      final audioData = base64Encode(_audioSamples.map((e) => (e * 255).toInt()).toList());
      
      // Call Azure NLP for analysis
      final analysis = await ref.read(speakingPerformanceProvider(
        SpeakingAnalysisParams(
          text: _text,
          audioData: audioData,
        ),
      ).future);

      if (mounted) {
        _showAnalysisDialog(analysis);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error analyzing speech: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isAnalyzing = false);
      }
    }
  }

  Future<void> _showAnalysisDialog(Map<String, dynamic> analysis) async {
    await showDialog(
      context: context,
      barrierDismissible: false, // Prevent closing by tapping outside
      builder: (context) => WillPopScope(
        onWillPop: () async => false, // Prevent closing with back button
        child: SpeakingAnalysisDialog(
          analysis: analysis,
          onClose: () => Navigator.of(context).pop(),
        ),
      ),
    );
  }
  
  String _formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('IELTS Speaking Practice'),
        actions: [
          if (_isAnalyzing)
            const Padding(
              padding: EdgeInsets.only(right: 16.0),
              child: Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
      body: Container(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Time Remaining:',
                  style: TextStyle(fontSize: 16.0),
                ),
                Text(
                  _formatTime(_secondsRemaining),
                  style: const TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 16.0),
            const Text(
              'You have 2 minutes to practice speaking. Tap the microphone to start.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16.0),
            ),
            const SizedBox(height: 16.0),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: SingleChildScrollView(
                    child: Text(
                      _text.isEmpty ? 'Tap the microphone to start speaking...' : _text,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_isListening && _text.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: FloatingActionButton.extended(
                onPressed: () async {
                  await _stopListening();
                  await _analyzeSpeech();
                },
                label: const Text('Get Results'),
                icon: const Icon(Icons.analytics),
                backgroundColor: Theme.of(context).colorScheme.secondary,
              ),
            ),
          FloatingActionButton(
            onPressed: _isListening ? _stopListening : _startListening,
            child: Icon(_isListening ? Icons.stop : Icons.mic),
          ),
        ],
      ),
    );
  }
}
