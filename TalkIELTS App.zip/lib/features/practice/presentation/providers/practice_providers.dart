import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iel/features/auth/presentation/providers/auth_provider.dart';
import 'package:iel/features/practice/data/models/practice_item.dart';
import 'package:iel/features/practice/data/services/practice_service.dart';

final practiceServiceProvider = Provider<PracticeService>((ref) => PracticeService());

final practiceItemsProvider = StreamProvider.family<List<PracticeItem>, PracticeType?>((ref, type) {
  final user = ref.watch(currentUserProvider);
  if (user == null) return Stream.value([]);

  return ref.watch(practiceServiceProvider).getPracticeItems(user.uid, type: type);
});

final practiceItemProvider = FutureProvider.family<PracticeItem, String>((ref, itemId) {
  final user = ref.watch(currentUserProvider);
  if (user == null) throw Exception('User not authenticated');

  return ref.watch(practiceServiceProvider).getPracticeItem(user.uid, itemId);
});

final practiceStatsProvider = FutureProvider<Map<PracticeType, double>>((ref) {
  final user = ref.watch(currentUserProvider);
  if (user == null) return Future.value({
    PracticeType.writing: 0.0,
    PracticeType.speaking: 0.0,
  });

  return ref.watch(practiceServiceProvider).getPracticeStats(user.uid);
});

final recommendedPracticeProvider = FutureProvider<PracticeType>((ref) {
  final user = ref.watch(currentUserProvider);
  if (user == null) return Future.value(PracticeType.speaking);

  return ref.watch(practiceServiceProvider).getRecommendedPractice(user.uid);
});
