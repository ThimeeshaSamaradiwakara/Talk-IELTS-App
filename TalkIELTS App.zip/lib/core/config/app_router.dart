import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iel/features/auth/presentation/screens/splash_screen.dart';
import 'package:iel/features/auth/presentation/screens/login_screen.dart';
import 'package:iel/features/auth/presentation/screens/register_screen.dart';
import 'package:iel/features/home/presentation/screens/home_screen.dart';
import 'package:iel/features/practice/presentation/screens/speaking_practice_screen.dart';
import 'package:iel/features/exam/presentation/screens/exam_list_screen.dart';
import 'package:iel/features/exam/presentation/screens/exam_screen.dart';
import 'package:iel/features/exam/domain/models/exam_model.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>();

final router = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: '/splash',
  routes: [
    GoRoute(
      path: '/splash',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/register',
      builder: (context, state) => const RegisterScreen(),
    ),
    GoRoute(
      path: '/home',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/practice/speaking',
      builder: (context, state) => const SpeakingPracticeScreen(),
    ),
    // Exam routes
    GoRoute(
      path: '/exams',
      builder: (context, state) => const ExamListScreen(),
    ),
    GoRoute(
      path: '/exam/:id',
      builder: (context, state) {
        final exam = state.extra as Exam?;
        if (exam == null) {
          return const Scaffold(
            body: Center(child: Text('Exam not found')),
          );
        }
        return ExamScreen(exam: exam);
      },
    ),
  ],
  errorBuilder: (context, state) => const Scaffold(
    body: Center(child: Text('Page not found!')),
  ),
);
