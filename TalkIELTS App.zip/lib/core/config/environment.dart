class Environment {
  static String get geminiApiKey => const String.fromEnvironment(
    'GEMINI_API_KEY',
    defaultValue: '',
  );
}
