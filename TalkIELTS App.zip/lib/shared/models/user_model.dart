class UserModel {
  final String id;
  final String name;
  final String email;
  final String? photoUrl;
  final double? overallScore;
  final Map<String, double>? skillScores;
  final int practiceSessionsCompleted;
  final int minutesStudied;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    this.photoUrl,
    this.overallScore,
    this.skillScores,
    this.practiceSessionsCompleted = 0,
    this.minutesStudied = 0,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String,
      name: json['name'] as String,
      email: json['email'] as String,
      photoUrl: json['photoUrl'] as String?,
      overallScore: json['overallScore'] as double?,
      skillScores: json['skillScores'] != null
          ? Map<String, double>.from(json['skillScores'] as Map)
          : null,
      practiceSessionsCompleted: json['practiceSessionsCompleted'] as int? ?? 0,
      minutesStudied: json['minutesStudied'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'photoUrl': photoUrl,
      'overallScore': overallScore,
      'skillScores': skillScores,
      'practiceSessionsCompleted': practiceSessionsCompleted,
      'minutesStudied': minutesStudied,
    };
  }

  UserModel copyWith({
    String? id,
    String? name,
    String? email,
    String? photoUrl,
    double? overallScore,
    Map<String, double>? skillScores,
    int? practiceSessionsCompleted,
    int? minutesStudied,
  }) {
    return UserModel(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      photoUrl: photoUrl ?? this.photoUrl,
      overallScore: overallScore ?? this.overallScore,
      skillScores: skillScores ?? this.skillScores,
      practiceSessionsCompleted:
          practiceSessionsCompleted ?? this.practiceSessionsCompleted,
      minutesStudied: minutesStudied ?? this.minutesStudied,
    );
  }
}
