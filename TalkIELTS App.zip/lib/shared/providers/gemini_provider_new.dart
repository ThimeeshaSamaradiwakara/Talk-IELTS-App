import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/gemini_service.dart';
import '../services/gemini_service_impl.dart';

final geminiProvider = Provider<GeminiService>((ref) {
  const apiKey = 'AIzaSyA-8YhEKXGhDYRep9UDg-WvrL98GPLCCZ8';
  return GeminiServiceImpl(apiKey: apiKey);
});

final textAnalysisProvider = FutureProvider.autoDispose
    .family<Map<String, dynamic>, String>((ref, text) async {
  final geminiService = ref.watch(geminiProvider);
  return await geminiService.analyzeText(text);
});

final listeningPromptProvider = FutureProvider.autoDispose<String>((ref) async {
  final geminiService = ref.watch(geminiProvider);
  return await geminiService.generateListeningPrompt();
});
