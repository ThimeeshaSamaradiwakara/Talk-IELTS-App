import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iel/features/auth/presentation/providers/auth_provider.dart';
import 'package:iel/shared/models/user_model.dart';
import 'package:iel/shared/services/user_service.dart';

final userServiceProvider = Provider<UserService>((ref) => UserService());

final currentUserDataProvider = StreamProvider<UserModel?>((ref) {
  final user = ref.watch(currentUserProvider);
  if (user == null) return Stream.value(null);

  return ref.watch(userServiceProvider).getUserStream(user.uid);
});

final userScoreProvider = Provider.family<double?, String>((ref, skill) {
  return ref.watch(currentUserDataProvider).when(
        data: (user) => user?.skillScores?[skill],
        loading: () => null,
        error: (_, __) => null,
      );
});
