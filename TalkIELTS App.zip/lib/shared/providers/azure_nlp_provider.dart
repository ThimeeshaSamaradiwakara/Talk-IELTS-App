import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:iel/shared/services/azure_nlp_service.dart';

final azureNLPServiceProvider = Provider<AzureNLPService>((ref) {
  const storage = FlutterSecureStorage();

  const endpoint = 'https://eastus.api.cognitive.microsoft.com/';
  const apiKey = 'bd4966704e5b4dedb56e708e7083b1e0';

  return AzureNLPService(
    endpoint: endpoint,
    apiKey: apiKey,
  );
});

final writingAnalysisProvider = FutureProvider.family<double, String>((ref, text) async {
  final nlpService = ref.read(azureNLPServiceProvider);
  return nlpService.analyzeWritingTask(text);
});

final speakingAnalysisProvider = FutureProvider.family<Map<String, dynamic>, String>((ref, text) async {
  final nlpService = ref.read(azureNLPServiceProvider);
  return nlpService.analyzeSpeakingTask(text);
});

final readingAnalysisProvider = FutureProvider.family<Map<String, List<String>>, ({String text, String answer})>((ref, params) async {
  final nlpService = ref.read(azureNLPServiceProvider);
  return nlpService.analyzeReadingComprehension(params.text, params.answer);
});
