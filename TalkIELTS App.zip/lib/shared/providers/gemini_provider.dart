import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

// Gemini model provider
final geminiModelProvider = Provider<GenerativeModel>((ref) {
  return GenerativeModel(
    model: 'gemini-2.0-flash',
    apiKey: 'AIzaSyA-8YhEKXGhDYRep9UDg-WvrL98GPLCCZ8',
  );
});

// Provider to generate questions for a reading text
final geminiGenerateQuestionsProvider = FutureProvider.family<List<Map<String, dynamic>>, String>((ref, text) async {
  final model = ref.read(geminiModelProvider);

  // Prompt to generate questions
  final prompt = '''
  Generate 5 reading comprehension questions based on the following text.
  Format the response as a JSON array with each question having:
  1. "id" (unique string)
  2. "text" (the question text)
  3. "type" (either "multiple_choice" or "open_ended")
  4. "options" (array of 4 choices, only for multiple_choice questions)

  Here's the text:

  $text
  ''';

  // Generate questions
  final response = await model.generateContent(prompt);
  final responseText = response.text;

  if (responseText == null || responseText.isEmpty) {
    throw Exception('Failed to generate questions');
  }

  // Extract JSON from the response (in case there's any explanatory text)
  final jsonMatch = RegExp(r'\[\s*{.*}\s*\]', dotAll: true).firstMatch(responseText);
  if (jsonMatch == null) {
    throw Exception('Invalid response format');
  }

  try {
    final jsonString = jsonMatch.group(0);
    final List<dynamic> parsed = jsonDecode(jsonString!);

    // Ensure each question has an ID
    const uuid = Uuid();
    final questions = parsed.map((q) {
      return {
        'id': q['id'] ?? uuid.v4(),
        'text': q['text'],
        'type': q['type'],
        'options': q['options'],
      };
    }).toList();

    return List<Map<String, dynamic>>.from(questions);
  } catch (e) {
    throw Exception('Failed to parse questions: $e');
  }
});

class GenerativeModel {
  final String model;
  final String apiKey;

  GenerativeModel({required this.model, required this.apiKey});

  Future<ContentResponse> generateContent(String prompt) async {
    final url = Uri.parse('https://generativelanguage.googleapis.com/v1/models/$model:generateContent');
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'prompt': prompt,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return ContentResponse.fromJson(data);
    } else {
      throw Exception('Failed to generate content: ${response.reasonPhrase}');
    }
  }

  Future<double> evaluateAnswer(String answer) async {
    final url = Uri.parse('https://gemini-api.example.com/evaluate'); // Replace with the actual Gemini API endpoint
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'model': model,
        'answer': answer,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      // Assuming the API returns a score in the response
      return data['score'] as double;
    } else {
      throw Exception('Failed to evaluate answer: ${response.reasonPhrase}');
    }
  }
}

class ContentResponse {
  final String text;

  ContentResponse({required this.text});

  factory ContentResponse.fromJson(Map<String, dynamic> json) {
    return ContentResponse(
      text: json['text'] ?? '',
    );
  }
}
