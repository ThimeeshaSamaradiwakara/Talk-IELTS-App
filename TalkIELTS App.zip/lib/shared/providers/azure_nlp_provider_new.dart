import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/azure_nlp_service_impl.dart';

final azureNLPProvider = Provider<AzureNLPService>((ref) => AzureNLPService());

/// Provider for basic text analysis (backward compatibility)
final speakingAnalysisProvider = FutureProvider.autoDispose
    .family<Map<String, dynamic>, String>((ref, text) async {
  final nlpService = ref.watch(azureNLPProvider);
  return await nlpService.analyzeText(text);
});

/// Provider for comprehensive speaking performance analysis
final speakingPerformanceProvider = FutureProvider.autoDispose
    .family<Map<String, dynamic>, SpeakingAnalysisParams>((ref, params) async {
  final nlpService = ref.watch(azureNLPProvider);
  return await nlpService.analyzeSpeakingPerformance(
    params.text,
    audioData: params.audioData,
  );
});

/// Parameters for speaking performance analysis
class SpeakingAnalysisParams {
  final String text;
  final String? audioData;

  SpeakingAnalysisParams({
    required this.text,
    this.audioData,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SpeakingAnalysisParams &&
          runtimeType == other.runtimeType &&
          text == other.text &&
          audioData == other.audioData;

  @override
  int get hashCode => text.hashCode ^ (audioData?.hashCode ?? 0);
}
