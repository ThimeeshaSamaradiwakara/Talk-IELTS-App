library gemini_service;

export 'gemini_service_impl.dart';

/// Interface for interacting with the Gemini AI service
abstract class GeminiService {
  /// Generates text based on the given prompt
  Future<String> generateText(String prompt);
  
  /// Analyzes the given text and returns feedback
  Future<Map<String, dynamic>> analyzeText(String text);
  
  /// Generates a listening practice prompt for language learning
  Future<String> generateListeningPrompt();
}
