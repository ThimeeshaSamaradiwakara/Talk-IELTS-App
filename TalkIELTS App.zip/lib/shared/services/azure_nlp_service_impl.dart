import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class AzureNLPService {
  // Azure Language Service endpoint (update with your region)
  static const String _endpoint = 'https://EastUS.api.cognitive.microsoft.com/language/:analyze-text';
  static const String _apiKey = 'FMmwm53zpALcSElwsvUFskJl9u0rRfNe8CZyIntuiM4fMIjewA2rJQQJ99BEACYeBjFXJ3w3AAAaACOG6bLI';
  
  // Speech Service endpoint for pronunciation assessment (update with your region)
  static const String _speechEndpoint = 'https://EastUS.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1';
  static const String _speechApiKey = '41cfef7fee4f43fabfc904f73624f55d';

  // Analyze speaking performance with comprehensive metrics
  Future<Map<String, dynamic>> analyzeSpeakingPerformance(String text, {String? audioData}) async {
    try {
      // 1. Get text analytics (sentiment, key phrases, entities, etc.)
      final textAnalytics = await _analyzeTextComprehensive(text);
      
      // 2. If audio data is available, get pronunciation assessment
      final pronunciationAssessment = audioData != null 
          ? await _assessPronunciation(text, audioData) 
          : await _estimatePronunciationFromText(text);
      
      // 3. Calculate grammar and vocabulary metrics
      final grammarMetrics = _analyzeGrammarAndVocabulary(text);
      
      // 4. Calculate fluency metrics
      final fluencyMetrics = _analyzeFluency(text);
      
      // 5. Combine all metrics
      final pronunciationScore = (pronunciationAssessment['score'] as num?)?.toDouble();
      final grammarScore = (grammarMetrics['score'] as num?)?.toDouble();
      final fluencyScore = (fluencyMetrics['score'] as num?)?.toDouble();
      
      return {
        'textAnalytics': textAnalytics,
        'pronunciation': pronunciationAssessment,
        'grammar': grammarMetrics,
        'fluency': fluencyMetrics,
        'overallScore': _calculateOverallScore(
          pronunciationScore,
          grammarScore,
          fluencyScore,
        ),
        'detailedFeedback': _generateDetailedFeedback(
          textAnalytics,
          pronunciationAssessment,
          grammarMetrics,
          fluencyMetrics,
        ),
      };
    } catch (e) {
      debugPrint('Error in analyzeSpeakingPerformance: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> _analyzeTextComprehensive(String text) async {
    try {
      final response = await http.post(
        Uri.parse(_endpoint.replaceAll(':analyze-text', 'text/analytics/v3.2-preview.1/analyze')),
        headers: _getHeaders(),
        body: jsonEncode({
          'analysisInput': {
            'documents': [
              {
                'id': '1',
                'language': 'en',
                'text': text,
              },
            ],
          },
          'tasks': {
            'entityRecognitionTasks': [{
              'parameters': {'model-version': 'latest'}
            }],
            'keyPhraseExtractionTasks': [{
              'parameters': {'model-version': 'latest'}
            }],
            'sentimentAnalysisTasks': [{
              'parameters': {
                'model-version': 'latest',
                'opinionMining': true
              }
            }],
            'entityLinkingTasks': [{
              'parameters': {'model-version': 'latest'}
            }],
          },
        }),
      );

      return _processTextAnalyticsResponse(response);
    } catch (e) {
      debugPrint('Error in _analyzeTextComprehensive: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> _assessPronunciation(String text, String audioData) async {
    try {
      // This is a simplified version - in a real app, you'd need to handle audio streaming
      // and proper WAV format conversion
      final referenceText = text.toLowerCase();
      
      final response = await http.post(
        Uri.parse('${_speechEndpoint}?language=en-US&format=detailed'),
        headers: {
          'Ocp-Apim-Subscription-Key': _speechApiKey,
          'Content-Type': 'audio/wav; codecs=audio/pcm; samplerate=16000',
          'Pronunciation-Assessment': jsonEncode({
            'referenceText': referenceText,
            'gradingSystem': 'HundredMark',
            'granularity': 'Phoneme',
            'dimension': 'Comprehensive',
          }),
        },
        body: base64Decode(audioData),
      );

      return _processPronunciationResponse(response);
    } catch (e) {
      debugPrint('Error in _assessPronunciation: $e');
      return _estimatePronunciationFromText(text);
    }
  }

  Map<String, dynamic> _analyzeGrammarAndVocabulary(String text) {
    // Implement grammar and vocabulary analysis
    // This is a simplified version - in a real app, you'd use more sophisticated analysis
    final words = text.split(' ');
    final wordCount = words.length;
    final uniqueWords = words.toSet().length;
    final avgWordLength = words.fold(0, (sum, word) => sum + word.length) / wordCount;
    
    // Calculate grammar score (simplified)
    final grammarScore = (0.7 + (uniqueWords / wordCount) * 0.3) * 100;
    
    return {
      'wordCount': wordCount,
      'uniqueWords': uniqueWords,
      'vocabularyDiversity': (uniqueWords / wordCount).toStringAsFixed(2),
      'avgWordLength': avgWordLength.toStringAsFixed(2),
      'score': grammarScore.clamp(0, 100).toDouble(),
      'suggestions': _generateGrammarSuggestions(text),
    };
  }
  
  Map<String, dynamic> _analyzeFluency(String text) {
    // Implement fluency analysis
    final sentences = text.split(RegExp(r'[.!?]'));
    final sentenceCount = sentences.length;
    final words = text.split(' ');
    final wordCount = words.length;
    
    // Calculate words per sentence
    final wordsPerSentence = wordCount / sentenceCount;
    
    // Calculate fluency score (simplified)
    final fluencyScore = (0.6 + (min(wordsPerSentence, 20) / 20) * 0.4) * 100;
    
    return {
      'sentenceCount': sentenceCount,
      'wordsPerSentence': wordsPerSentence.toStringAsFixed(2),
      'score': fluencyScore.clamp(0, 100).toDouble(),
      'suggestions': _generateFluencySuggestions(wordsPerSentence),
    };
  }
  
  double _calculateOverallScore(double? pronunciation, double? grammar, double? fluency) {
    // Handle null values by providing defaults (0.0)
    final pronunciationScore = pronunciation ?? 0.0;
    final grammarScore = grammar ?? 0.0;
    final fluencyScore = fluency ?? 0.0;
    
    // Weighted average with pronunciation being most important
    return (pronunciationScore * 0.5 + grammarScore * 0.3 + fluencyScore * 0.2).clamp(0, 100).toDouble();
  }
  
  String _generateDetailedFeedback(
    Map<String, dynamic> textAnalytics,
    Map<String, dynamic> pronunciation,
    Map<String, dynamic> grammar,
    Map<String, dynamic> fluency,
  ) {
    final buffer = StringBuffer();
    
    // Pronunciation feedback
    buffer.writeln('## Pronunciation: ${pronunciation['score']?.toStringAsFixed(1) ?? 'N/A'}');
    if (pronunciation['suggestions'] != null) {
      for (final suggestion in (pronunciation['suggestions'] as List)) {
        buffer.writeln('- $suggestion');
      }
    }
    
    // Grammar feedback
    buffer.writeln('\n## Grammar & Vocabulary: ${grammar['score']?.toStringAsFixed(1) ?? 'N/A'}');
    buffer.writeln('- Vocabulary diversity: ${grammar['vocabularyDiversity']} (higher is better)');
    if (grammar['suggestions'] != null) {
      for (final suggestion in (grammar['suggestions'] as List)) {
        buffer.writeln('- $suggestion');
      }
    }
    
    // Fluency feedback
    buffer.writeln('\n## Fluency: ${fluency['score']?.toStringAsFixed(1) ?? 'N/A'}');
    buffer.writeln('- Average words per sentence: ${fluency['wordsPerSentence']}');
    if (fluency['suggestions'] != null) {
      for (final suggestion in (fluency['suggestions'] as List)) {
        buffer.writeln('- $suggestion');
      }
    }
    
    // Sentiment feedback
    final sentiment = textAnalytics['sentiment']?['document']?['sentiment'];
    if (sentiment != null) {
      buffer.writeln('\n## Sentiment: ${sentiment.toString().toUpperCase()}');
    }
    
    // Key phrases
    final keyPhrases = textAnalytics['keyPhrases'];
    if (keyPhrases != null && keyPhrases.isNotEmpty) {
      buffer.writeln('\n## Key Phrases:');
      buffer.writeln(keyPhrases.join(', '));
    }
    
    return buffer.toString();
  }
  
  // Helper methods for processing responses and generating suggestions
  Map<String, dynamic> _processTextAnalyticsResponse(http.Response response) {
    // Process and format the response from Azure Text Analytics
    // Implementation depends on the exact response format
    return {};
  }
  
  Map<String, dynamic> _processPronunciationResponse(http.Response response) {
    // Process and format the pronunciation assessment response
    // Implementation depends on the exact response format
    return {};
  }
  
  Future<Map<String, dynamic>> _estimatePronunciationFromText(String text) async {
    // Fallback method to estimate pronunciation quality from text only
    // This is less accurate than actual speech analysis
    final wordCount = text.split(' ').length;
    final score = (0.7 + min(wordCount / 50, 0.3)) * 100; // Base score + length bonus
    
    return {
      'score': score.clamp(0, 100).toDouble(),
      'suggestions': [
        'Speak clearly and at a natural pace.',
        'Focus on word stress and intonation.',
      ],
    };
  }
  
  List<String> _generateGrammarSuggestions(String text) {
    // Simple grammar suggestions based on common patterns
    final suggestions = <String>[];
    
    // Check for common issues
    if (text.split(' ').length < 5) {
      suggestions.add('Try to speak in complete sentences.');
    }
    
    if (!text.endsWith('.') && !text.endsWith('!') && !text.endsWith('?')) {
      suggestions.add('Remember to end your sentences with proper punctuation.');
    }
    
    if (suggestions.isEmpty) {
      suggestions.add('Your grammar and vocabulary usage is good. Keep practicing!');
    }
    
    return suggestions;
  }
  
  List<String> _generateFluencySuggestions(double wordsPerSentence) {
    if (wordsPerSentence < 5) {
      return ['Try to speak in longer, more complete sentences.'];
    } else if (wordsPerSentence > 20) {
      return ['Consider breaking up long sentences for better clarity.'];
    } else {
      return ['Your sentence length is good for clear communication.'];
    }
  }
  
  Map<String, String> _getHeaders() => {
    'Content-Type': 'application/json',
    'Ocp-Apim-Subscription-Key': _apiKey,
  };
  
  // Backward compatibility
  Future<Map<String, dynamic>> analyzeText(String text) async {
    final result = await analyzeSpeakingPerformance(text);
    return {
      'sentiment': result['textAnalytics']?['sentiment'],
      'keyPhrases': result['textAnalytics']?['keyPhrases'],
      'score': result['overallScore'],
      'feedback': result['detailedFeedback'],
    };
  }
}
