import 'package:flutter/foundation.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'gemini_service.dart';

class GeminiServiceImpl implements GeminiService {
  final String _apiKey;
  late final GenerativeModel _model;

  GeminiServiceImpl({required String apiKey}) : _apiKey = apiKey {
    _model = GenerativeModel(
      model: 'gemini-2.0-flash',
      apiKey: "AIzaSyA-8YhEKXGhDYRep9UDg-WvrL98GPLCCZ8",
    );
  }

  Future<String> generateText(String prompt) async {
    try {
      final content = [Content.text(prompt)];
      final response = await _model.generateContent(content);
      return response.text ?? 'No response from model';
    } catch (e) {
      throw Exception('Error generating text: $e');
    }
  }

  Future<Map<String, dynamic>> analyzeText(String text) async {
    try {
      final prompt = '''
      Analyze the following text and provide feedback on:
      1. Grammar (0-100)
      2. Vocabulary (0-100)
      3. Coherence (0-100)
      4. Overall score (0-100)
      5. Suggestions for improvement
      
      Text: "$text"
      
      Respond in JSON format with these keys: grammar, vocabulary, coherence, score, suggestions
      ''';

      final response = await generateText(prompt);
      return _parseAnalysisResponse(response);
    } catch (e) {
      throw Exception('Error analyzing text: $e');
    }
  }

  Map<String, dynamic> _parseAnalysisResponse(String response) {
    try {
      // Remove markdown code blocks if present
      response =
          response.replaceAll('```json', '').replaceAll('```', '').trim();

      return {
        'grammar': 0.0,
        'vocabulary': 0.0,
        'coherence': 0.0,
        'score': 0.0,
        'suggestions':
            'Enable the Google Generative AI API and add your API key to use this feature.',
      };
    } catch (e) {
      throw Exception('Failed to parse analysis response: $e');
    }
  }

  /// Generates a listening practice prompt for English language learners
  Future<String> generateListeningPrompt() async {
    try {
      const prompt = '''
      Generate a short English listening practice prompt for language learners.
      The prompt should be 1-2 sentences long and use simple vocabulary.
      It should be appropriate for intermediate English learners.
      Focus on everyday situations like:
      - Directions
      - Shopping
      - Ordering food
      - Making plans
      - Describing people or places
      
      Example: "Could you tell me how to get to the nearest train station from here?"
      
      Generate a new, different prompt:
      ''';
      
      final content = [Content.text(prompt)];
      final response = await _model.generateContent(content);
      return response.text?.trim() ?? 'Please go straight and turn left at the traffic lights.';
    } catch (e) {
      debugPrint('Error generating listening prompt: $e');
      return 'Could you please tell me what time the next bus arrives?';
    }
  }
}
