library azure_nlp_service;

export 'azure_nlp_service_impl.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AzureNLPService {
  final String _endpoint;
  final String _apiKey;
  final _storage = const FlutterSecureStorage();
  final _client = http.Client();

  AzureNLPService({
    required String endpoint,
    required String apiKey,
  })  : _endpoint = endpoint,
        _apiKey = apiKey;

  Future<double> analyzeWritingTask(String text) async {
    try {
      final sentimentUrl = Uri.parse('$_endpoint/text/analytics/v3.0/sentiment');
      final syntaxUrl = Uri.parse('$_endpoint/text/analytics/v3.0/syntax');

      final headers = {
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key': _apiKey,
      };

      final body = jsonEncode({
        'documents': [
          {
            'id': '1',
            'text': text,
            'language': 'en',
          },
        ],
      });

      final sentimentResponse = await _client.post(sentimentUrl, headers: headers, body: body);
      final syntaxResponse = await _client.post(syntaxUrl, headers: headers, body: body);

      if (sentimentResponse.statusCode != 200 || syntaxResponse.statusCode != 200) {
        throw Exception('Failed to analyze text');
      }

      final sentimentData = jsonDecode(sentimentResponse.body);
      final syntaxData = jsonDecode(syntaxResponse.body);

      // Calculate score based on various factors
      final score = _calculateWritingScore(
        sentiment: sentimentData['documents'][0],
        grammar: syntaxData['documents'][0],
      );

      return score;
    } catch (e) {
      throw Exception('Error analyzing writing task: $e');
    }
  }

  Future<Map<String, dynamic>> analyzeSpeakingTask(String transcription) async {
    try {
      final sentimentUrl = Uri.parse('$_endpoint/text/analytics/v3.0/sentiment');
      final syntaxUrl = Uri.parse('$_endpoint/text/analytics/v3.0/syntax');

      final headers = {
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key': _apiKey,
      };

      final body = jsonEncode({
        'documents': [
          {
            'id': '1',
            'text': transcription,
            'language': 'en',
          },
        ],
      });

      final sentimentResponse = await _client.post(sentimentUrl, headers: headers, body: body);
      final syntaxResponse = await _client.post(syntaxUrl, headers: headers, body: body);

      if (sentimentResponse.statusCode != 200 || syntaxResponse.statusCode != 200) {
        throw Exception('Failed to analyze text');
      }

      final sentimentData = jsonDecode(sentimentResponse.body);
      final syntaxData = jsonDecode(syntaxResponse.body);

      // Calculate various aspects of speaking performance
      double fluencyScore = 0.0;
      double pronunciationScore = 0.0;
      double grammarScore = 0.0;
      double vocabularyScore = 0.0;

      // Analyze sentiment for natural flow
      fluencyScore = _calculateSentimentScore(sentimentData['documents'][0]);

      // Analyze grammar and vocabulary
      final scores = _analyzeSpeakingGrammar(syntaxData['documents'][0]);
      grammarScore = scores['grammar'] ?? 0.0;
      vocabularyScore = scores['vocabulary'] ?? 0.0;

      // Analyze pronunciation using text patterns
      pronunciationScore = _analyzePronunciation(transcription);

      return {
        'fluency': fluencyScore,
        'pronunciation': pronunciationScore,
        'grammar': grammarScore,
        'vocabulary': vocabularyScore,
        'overall': (fluencyScore + pronunciationScore + grammarScore + vocabularyScore) / 4,
      };
    } catch (e) {
      throw Exception('Error analyzing speaking task: $e');
    }
  }

  Future<Map<String, List<String>>> analyzeReadingComprehension(
    String text,
    String answer,
  ) async {
    try {
      final keyPhrasesUrl = Uri.parse('$_endpoint/text/analytics/v3.0/keyPhrases');

      final headers = {
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key': _apiKey,
      };

      final body = jsonEncode({
        'documents': [
          {
            'id': '1',
            'text': text,
            'language': 'en',
          },
          {
            'id': '2',
            'text': answer,
            'language': 'en',
          },
        ],
      });

      final response = await _client.post(keyPhrasesUrl, headers: headers, body: body);

      if (response.statusCode != 200) {
        throw Exception('Failed to analyze text');
      }

      final data = jsonDecode(response.body);

      // Compare key phrases for comprehension analysis
      final textKeyPhrases = data['documents'][0]['keyPhrases'].map((e) => e.toLowerCase()).toList();
      final answerKeyPhrases = data['documents'][1]['keyPhrases'].map((e) => e.toLowerCase()).toList();

      // Find matching and missing concepts
      final matchingConcepts = textKeyPhrases.intersection(answerKeyPhrases).toList();
      final missingConcepts = textKeyPhrases.difference(answerKeyPhrases).toList();

      return {
        'matching_concepts': matchingConcepts,
        'missing_concepts': missingConcepts,
      };
    } catch (e) {
      throw Exception('Error analyzing reading comprehension: $e');
    }
  }

  double _calculateWritingScore({
    required Map<String, dynamic> sentiment,
    required Map<String, dynamic> grammar,
  }) {
    // Calculate score based on sentiment and grammar analysis
    double score = 0.0;

    // Add sentiment score (0-1)
    score += (sentiment['confidenceScores']['positive'] ?? 0.0) * 0.3;

    // Add grammar score (0-1)
    final grammarScore = grammar['sentences']?.length ?? 0;
    score += (grammarScore / 10).clamp(0.0, 1.0) * 0.7;

    return score;
  }

  double _calculateSentimentScore(Map<String, dynamic> sentiment) {
    // Convert sentiment analysis to a score
    double score = 0.0;

    // Positive sentiment indicates better language use
    score += (sentiment['confidenceScores']['positive'] ?? 0.0) * 0.4;

    // Neutral sentiment also contributes
    score += (sentiment['confidenceScores']['neutral'] ?? 0.0) * 0.3;

    // Negative sentiment might indicate problems
    score -= (sentiment['confidenceScores']['negative'] ?? 0.0) * 0.3;

    // Normalize score to 0-1 range
    return (score + 1) / 2;
  }

  Map<String, double> _analyzeSpeakingGrammar(Map<String, dynamic> syntax) {
    int totalTokens = syntax['tokens']?.length ?? 0;
    int complexStructures = 0;
    int uniqueWords = syntax['tokens']?.map((t) => t['text'].toLowerCase())?.toSet().length ?? 0;

    for (var token in syntax['tokens'] ?? []) {
      if (_isComplexStructure(token)) {
        complexStructures++;
      }
    }

    return {
      'grammar': complexStructures / totalTokens,
      'vocabulary': uniqueWords / totalTokens,
    };
  }

  double _analyzePronunciation(String text) {
    // Analyze pronunciation patterns
    // This is a simplified version - in a real app, you'd want to use
    // more sophisticated phonetic analysis

    // Check for common pronunciation challenges
    final challenges = RegExp(r'th|ph|ch|sh|wh|ght|tion|sion');
    final words = text.split(' ');
    int difficultWords = 0;

    for (var word in words) {
      if (challenges.hasMatch(word)) {
        difficultWords++;
      }
    }

    return 1.0 - (difficultWords / words.length);
  }

  bool _isComplexStructure(Map<String, dynamic> token) {
    // Define complex grammatical structures
    const complexParts = {
      'SCONJ', // Subordinating conjunction
      'CCONJ', // Coordinating conjunction
      'AUX', // Auxiliary verb
      'PART', // Particle
    };

    return complexParts.contains(token['partOfSpeech']);
  }
}
